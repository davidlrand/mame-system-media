#include <stdio.h>
#include <ctype.h>
#include "32kdef.h"

int fi,open(),openx(),openxa();
long lseek();

#define MAXARG 300
#define MAX 512
#define RDBUFSIZE 32640
#define MAXOPF 40
    
char *rdbuf_;		/* pointer to 32K buffer */
long rdoff_;		/* Current file offset */
int  rdbyt_;		/* Current number of bytes in buffer */
int  rdpos_;		/* Current offset into buffer */
char *buffer,*fixn;
long start;

static char *erm[]={
"Loader version 2.00  09/26/85",
"File too short! Possible non-32k file.",
"Seek error during program load. Possible non-32k file.",
"File read error during program load. File corrupt.",
"Could not allocate sufficient memory.",
"is not a 32000 executable file."
};

int ftype[MAXOPF];

int _argc=0;
char *_argv[MAXARG];
char *lastnm;



VOID error(),fix();

main(argc,argv)
int argc;
char *argv[];
{
    int time,x,mstat;
    char *tq,*myalloc();
    VOID load();

    for (x=0; x < MAXOPF; x++) 
	ftype[x] = 0;		/* All files in binary */

    ftype[0]=ftype[1]=ftype[2]=1;	/* Except STDIN, STDOUT, STDERR */
    for (x=argc; x>=0; x--) 
	strtol(argv[x]);
    /* Get local buffer space */
    
    buffer = myalloc(MAX);
    fixn = myalloc(30);
    lastnm = myalloc(30);
    rdbuf_ = myalloc(RDBUFSIZE);
    
    /* init 32k page zero */
    INIT();
    
    MOVE(start32k,0L,sizeof(start32k));
    
    /* Zero fill the communication area */
    tq=myalloc(4096);
    MOVE(tq,20L,4096);
    MOVE(tq,0x1000L,4096);
    MOVE(tq,8192L,4096);
    free(tq);
    
    mstat=time=0;

    load("32io");
#if debug
printf("\n");
#endif
    if (argc>1) {
	while (--argc) {
	    argv++;
	    if ((*argv[0]=='-') && (*(argv[0]+1)=='a')) {
		++argv;
		--argc;
		break;
	    }
	    if ((*argv[0]=='-')) {
		if (*(argv[0]+1)=='t')
		    time=TRUE;
		else if (*(argv[0]+1) == 'm')
		    mstat = TRUE;
	    } else {
		strcpy(lastnm,*argv);
		load(*argv);

#if debug
		printf("\n");
#endif
	    }
	}
	
	_argc=argc;
	for (x=0;x<=argc;x++)
	    _argv[x]=argv[x];
	
#if debug
	printf("\nStarting execution...\n\n");
#endif
	free(rdbuf_);
	if (time) 
	    EXECT();
	else 
	    EXEC();
	
	INIT();
    } else {
	printf(erm[0]);
	MOVE1(0x2267L,fixn,12);
	fixn[12]='\0';
	printf("\n32000 Kernel %s\n\n",fixn);
	printf("\nYou must supply a name to load.");
	exit(1);
    }
    
}

strtol(s)
char *s;
{
    while (*s)
	*s++ = tolower(*s);
}



VOID load(s)
char *s;
{
    struct GENINF *gen;
    char *namein,*fixname();
    VOID loadit();
    
    namein=fixname(s);
    
    fi=openx(namein,0);
    if (fi != -1) {
#if debug
printf("Loading %s...",namein);
#endif
    
	if (read(fi,buffer,32)==-1) 
	    error(1);
    
	gen = (struct GENINF *)buffer;
	
	if (gen->execid == 7700)
	    loadit(fi);
	else {
	    printf("\"%s\" ",namein);
	    error(5);
	}
	close(fi);
    } else {
	printf("\nFile %s not found.",namein);
	exit(1);
    }
}

char *fixname(s)
char *s;
{
    char *index();
    strcpy(fixn,s);
    if (index(fixn,'.')==NULL) {
	strcat(fixn,".e32");
    }
    return(fixn);
}

VOID loadit(fi)
int fi;
{
    struct GENINF *gen;
    struct MODDIR *mod,*directory;
    struct GMT *temp;
    struct MODREC *modrec;
    
    int t,curdir,curptr,totmrec;
    long totmod,realstart;
    char *myalloc();
    
    VOID sort(),ldblk();
    
    gen = (struct GENINF *)buffer;

    totmod=gen->modcount;
    
    /* Move general information to 32032 */
    MOVE(&gen->heap_low,0x2020L,16);

#ifdef debug
printf("Exec id=%d, Dirblk=%d, modcnt=%ld, modaddr=%ld\n",gen->execid,gen->dirblk,totmod,gen->modaddr);
#endif

    start=gen->modaddr;
    curdir=totmod;
    
    mod=(struct MODDIR *)myalloc(sizeof(struct MODDIR));

    lseek(fi,(long) (gen->dirblk*512)+((gen->mainmod-1L)*
		    sizeof(struct GENINF)),0);
    
    if (read(fi,mod,32)==-1) 
	error(1);

    realstart=mod->strtaddr;
    free(mod);
    
    lseek(fi,32L,0);
    temp=(struct GMT *)myalloc(16 * (int)totmod);
    if (read(fi,temp,16 * (int)totmod)== -1)
	error(1);
    
    temp->reserved = realstart + (&temp[(int)(gen->mainmod -1L)])->codead;
    (&temp[1])->reserved = gen->mainmod - 1L;
    
    MOVE(temp,start,16 * (int)totmod);
    start += 16L * totmod;
    
    free(temp);
    
    lseek(fi,(long) (gen->dirblk*512),0);
    curdir=totmod*64;
    
    directory=(struct MODDIR *)myalloc(curdir);
    modrec=(struct MODREC *)myalloc(3 * totmod * sizeof(struct MODREC));

    if (read(fi,directory,curdir)==-1)
	error(1);

    for (totmrec=curptr=t=0;curptr<totmod;curptr++) {
	modrec[t].record=directory[curptr].lblk;
	modrec[t].modoff=curptr;
	modrec[t].type='L';			/* Link information */
	t++;
	
	modrec[t].record=directory[curptr].cblk;
	modrec[t].modoff=curptr;
	modrec[t].type='C';			/* Code information */
	t++;
	
  
	modrec[t].record=directory[curptr].sbblk;
	modrec[t].modoff=curptr;
	modrec[t].type='S';
	t++;					/* Static base information */
    }
    if (t) {
	totmrec = t;
	sort(modrec,totmrec);
    }

    rdoff_ = -1;			/* Right now, we are nowhere */
    rdbyt_ = 0;				/* And we have no bytes in buffer */
    for (t=0;t<totmrec;t++) {

#ifdef debug
pinfo(&directory[modrec[t].modoff]);
#endif

	ldblk(fi,&modrec[t],&directory[modrec[t].modoff]);
    }
    free(modrec);
    free(directory);
}

#ifdef debug
pinfo(mod)
struct MODDIR *mod;
{
    int x;
    
    printf("Module ");
    
    for (x=0;x<8;x++) {
	putchar(mod->modnm[x]);
    }
    printf(" Code start %d, Link start %d, Entry %lx\n",mod->cblk,mod->lblk,mod->strtaddr);
}
#endif
    
VOID sort(modrec,totmrec)
struct MODREC *modrec;
int totmrec;
{
    int compare();
    qsort(modrec,totmrec,sizeof(struct MODREC),compare);
}

int compare(a,b)
struct MODREC *a,*b;
{
    return((a->record)-(b->record));
}


VOID ldblk(fi,modr,mod)
int fi;
struct MODREC *modr;
struct MODDIR *mod;
{
    int t;
    long offset;
    char *ld,*myalloc();

    switch(modr->type) {
    
	case 'C':
	    if ((offset=(long) mod->cblk*512l)>0) {

#ifdef debug
printf("\t(code) Now we load %ld bytes into physical address %lx\n",mod->clen,mod->caddr);
#endif

	
		mread(fi,offset,mod->caddr,mod->clen);
	    }
	    break;
	
	case 'L':

	    if ((offset=(long) mod->lblk*512l)>0) {

#ifdef debug
printf("\t(link) Now we load %ld bytes into physical address %lx\n",mod->llen,mod->laddr);
#endif
	
		mread(fi,offset,mod->laddr,mod->llen);
	    }
	    break;

	case 'S':

	    if ((offset=(long) mod->sbblk*512l)>0) {

#ifdef debug
printf("\t(sb) Now we load %ld bytes into physical address %lx\n",mod->slen,mod->saddr);
#endif
	
		mread(fi,offset,mod->saddr,mod->slen);
	    }
	    break;
	    
	default:
	    printf("Fatal error. Tried to load type \"%c\"\n",modr->type);
	    error(3);
    }
}

    
VOID error(x)
int x;
{
    printf(erm[x]);
    exit(1);
}

char *myalloc(x)
int x;
{
    char *t,*calloc();
    if ((t=calloc(x,1))==NULL) {
	printf("\n\n%d bytes: ",x);
	error(4);
    }
    return(t);
}


int _OPEN(s,x)
long s;
int x;
{
    char file[100];
    register int i;
    
    MOVE1(s,file,99);

#if debug
printf("Open request for \"%s\"\n",file);
#endif

    fix(file);

    if (x & 4) 
	i = openx(file, x&3);
    else 
	i = openxa(file, x&3);
    
    if ((x & _OP_EOF) && (i > 0))
	lseek(i,0L,2);  /* Seek to end of file, if that's what he wants.. */
	
    return(i);
}

VOID fix(s)
char *s;
{
    char *t,*t1;
    int len;
    
    t1=t=s;
    
    len=strlen(s);
    t1+=len;
    
    while ((*t1!='/') && (len != 0)) {
	len--;
	t1--;
    }
    if (len) 
	strcpy(t,++t1);
    
}

int _CREA(s,x)
long s;
int x;
{
    char file[100];
    register int i;
    
    MOVE1(s,file,99);

#if debug
printf("Create request for \"%s\"\n",file);
#endif

    fix(file);

    if (x & 4) 
	i = creat (file, x&3);
    else 
	i = creat( file, x);
	
    return(i);
}
    
int _CLOS(x)
int x;
{
    static char eof=0x1a;

#if debug
printf("Close request for %d\n",x);
#endif
    
    if (ftype[x] == 2)
	write(x,&eof,1);
	
    ftype[x] = 0;
    return(close(x));
}

int _READ(fd,buffer,bytes)
int fd;
long buffer;
int bytes;
{
    char *tbuf,*myalloc();
    int tret;
    
#if debug
printf("Reading %d bytes from %d into %8lx\n",bytes,fd,buffer);
#endif

    tbuf=myalloc(bytes);
	
    if (ftype[fd])
	tret = reada(fd,tbuf,bytes);
    else
	tret = read(fd,tbuf,bytes);
	
    if (tret!=-1) 
	MOVE(tbuf,buffer,bytes);
	
    free(tbuf);
    return(tret);
}

reada(fd,tbuf,bytes)
int fd,bytes;
char *tbuf;
{
    int lbytes, lret;
    char *pt1, *pt2;
    
    lret = read(fd,tbuf,bytes);
    
    if (lret >0) {
	pt1 = pt2 = tbuf;
	
	for (lbytes = lret; lbytes > 0; lbytes--) {
	    if (*pt1 == 0x1a)
		break;
	    if (*pt1 == 0x0d && lbytes > 1 && *(pt1 + 1) == 0x0a) {
		lbytes--;
		pt1++;
	    } else {
		if (*pt1 == 0x0d && lbytes == 1) 
		    *pt1 = 0x0a;
	    }
	    *pt2++ = *pt1++;
	}
	lret -= (pt1 - pt2);
    }
    return(lret);
}

    
int _WRIT(fd,buffer,bytes)
int fd;
long buffer;
int bytes;
{
    char *tbuf,*myalloc();
    int tret;
    
#if debug
printf("Writing %d bytes from %d into %8lx\n",bytes,fd,buffer);
#endif

    tbuf=myalloc(bytes);
    MOVE1(buffer,tbuf,bytes);
	
    if (ftype[fd])
	tret = writea(fd,tbuf,bytes);
    else
	tret = write(fd,tbuf,bytes);
	
    free(tbuf);
    return(tret);
}

writea(fd,tbuf,bytes)
int fd,bytes;
char *tbuf;
{
    int lret,lbytes,x;
    char *pt1,*pt2;
    static char cr = 0x0d;
    
    ftype[fd] = 2;
    pt1 = pt2 = tbuf;
	
    for (lbytes = bytes; lbytes > 0; lbytes--) {
	if (*pt1 == 0x0a) {
	    x = pt1 - pt2;
	    if ( (lret = write(fd,pt2,x)) != x)
		goto error;
	    if (write(fd,&cr,1) != 1)
		goto error;
	    pt2 = pt1;
	}
	pt1++;
    }
    lret = write(fd,pt2,(pt1 - pt2));
error:
    return(lret);
}

	
	
    

int _RENAM(file2,file1)
long file1,file2;
{
    char f1[100],f2[100];
    int ret;
    
    MOVE1(file1,f1,99);
    MOVE1(file2,f2,99);
    
#if debug
printf("Renaming \"%s\" to \"%s\"\n",f1,f2);
#endif
    
    if ((ret=open(f2,0)) != -1) {
	close(ret);
	ret = 1;
    } else {
	ret = rename(f1,f2);
    }
    return(ret);
}


long _SEEK(fd,offset,ptrname)
int fd;
long offset;
int ptrname;
{

#if debug
printf("Seeking in %d to %ld, with a mode of %d\n",fd,offset,ptrname);
#endif

    return(lseek(fd,offset,ptrname));
}

long _TELL(fd)
int fd;
{
    long tell();

#if debug
printf("Telling location of %d\n",fd);
#endif

    return(tell(fd));
}

long tell(fd)
int fd;
{
    long lseek();
    
    return(lseek(fd,0L,1));
}

    

int _UNLI(s,l)
long s;
int l;
{
    char file[100];
    MOVE1(s,file,99);

#if debug
printf("Unlinking %s\n",file);
#endif

    return(unlink(file));
}
    
    

_ARGP(len,dta)
long dta;
int len;
{
    char *loc,*temp,*myalloc();
    int curoff=0,x;
    long *t1;

    loc=temp=myalloc(len);

    t1=(long *)loc;
    
    *t1++=(long) _argc + 1L;
    
    *t1++ = (long) curoff;
    curoff += strlen(lastnm)+1;
    
    for (x=0;x<_argc;x++) {
	*t1++ = (long) curoff;
	curoff+=strlen(_argv[x])+1;
    }
    
    temp=(char *)t1;
    strcpy(temp,lastnm);
    temp += strlen(lastnm)+1;
    
    for (x=0;x<_argc;x++) {
	if (_argv[x][0]=='-' &&
	   (_argv[x][1]=='d' || _argv[x][1]=='x' || _argv[x][1]=='e' ||
	    _argv[x][1]=='z' || _argv[x][1]=='s'))
	    _argv[x][1]=toupper(_argv[x][1]);
	if (strcmp(_argv[x],"-o1")==0)
	    strcpy(_argv[x],"-O ");
	if (strcmp(_argv[x],"-o2")==0)
	    strcpy(_argv[x],"-O2");
	strcpy(temp,_argv[x]);
	temp+=strlen(_argv[x])+1;
    }
    
    
    MOVE(loc,dta,len);
    free(loc);
    
}

int mread(fd,offset,buffer,bytes)
int fd;
long offset,buffer;
long bytes;
{
    long locoff;
    register int lbytes;
    
    while (bytes) {	/* While we still have bytes to load */
	if (rdoff_ == -1) {	/* we don't know where we are */
	    rdoff_ = offset;	/* Point to current location */
	    if (lseek(fd,offset,0)==-1)
		error(2);
	    rdbyt_=0;
	}
	if (rdbyt_==0) {
	    rdbyt_ = read(fd,rdbuf_,RDBUFSIZE);
	    rdpos_ = 0;
	}
	if (rdbyt_==-1)
	    error(3);
	
	locoff = offset - rdoff_;	/* This is where we want to be */
	    

	if (locoff < 0) {
	printf("\nWe can't back up in file! Offset=%ld,%ld",offset,rdoff_);
	    exit(1);
	}
	
	if (locoff > (long)rdbyt_) {
	    /* If want to read in the next block, go there */
	    rdoff_+= (long) rdbyt_;
	    rdbyt_=0;
	} else {
	    rdoff_+=locoff;		/* Position to correct offset */
	    rdbyt_-=(int)locoff;	/* And decrement byte count */
	    rdpos_+=(int)locoff;	/* and correct position offset */
	    lbytes = (bytes > (long)rdbyt_) ? rdbyt_ : (int)bytes;
	    MOVE(&rdbuf_[rdpos_],buffer,lbytes);
	    buffer+= (long) lbytes;
	    bytes -= (long) lbytes;
	    offset+= (long) lbytes;
	    rdoff_+= (long) lbytes;
	    rdbyt_-= lbytes;
	    rdpos_+= lbytes;
	}
    }
    return(1);
}


    

int openx(s,i)
register char *s;
int i;
{
    char lclnam[100];
    int r1;
    
    if (s[1]==':') {
	r1 = open(s,i);
	goto ret;
    }
    
    if ((r1=open(s,i))!=-1)
	goto ret;
    
    lclnam[0]='A'+GETSYS();
    lclnam[1]=':';
    lclnam[2]='\0';
    strcat(lclnam,s);
    r1 = open(lclnam,i);
	
ret:
    if (r1 >= 0)
	ftype[r1] = 0;

    return(r1);
}

	
int openxa(s,i)
register char *s;
int i;
{
    char lclnam[100];
    int r1;
    
    if (s[1]==':') {
	r1 = open(s,i);
	goto ret;
    }
    
    if ((r1=open(s,i))!=-1)
	goto ret;
    
	
    lclnam[0]='A'+GETSYS();
    lclnam[1]=':';
    lclnam[2]='\0';
    strcat(lclnam,s);
    r1 = open(lclnam,i);
    
ret:
    if (r1 >= 0 )
	ftype[r1] = 1;
    return(r1);
}

	
/*
** File:                SETENV.C
** System:              Z-150
** Created:             20 September    1985
** Modified:            22 September    1985
**
** This program allows the user to read or set up the
** environment variables used by MS-DOS format programs.
**
** SETENV was successfully compiled with the ECO-SOFT
** ECO-C88 compiler, version 2.81.
**
** The program accepts the following command lines:
**
**      SETENV <return>
**              displays the current environment
**
**      SETENV VARNAME <return>
**              displays the variable setting
**
**      SETENV -VARNAME <return>
**              deletes the environment variable
**
**      SETENV VARNAME PARM1 [PARM2 ... PARMN] <return>
**              Sets the environment variable to the values passed
**              as PARM1 through PARMN.
*/

#include "dos.h"
#define NULL 0

struct  VAR
{
  struct VAR    *link;
  char          string[81];
};

char            *alloc();
char            *getenv();
char            *itoa();
char            *strcpy();
char            *strcat();

int             strncmp();
      
unsigned        getds();
unsigned        peek();

void            segread();

void stoupper(what)

/*
** This routine converts a string into all upper case
** alpha.  All other characters are returned undisturbed.
*/

char            *what;

{
  int           counter;
  
  counter = 0;
  while((what[counter] = toupper(what[counter])) != '\0')
    counter++;
}  
  
void putback(what)

/*
** Routine traces through a linked list and returns the
** memory space to the operating system.  The routine
** expects the root of the list to be passed to it and
** traces through the list.
*/

struct VAR      *what;

{
  struct VAR    *current;
  struct VAR    *next;
  
  current = what;
  while (current->link != NULL)
  {
    next = current->link;
    free(current);
    current = next;
  }
}
  

main(argc, argv)

int             argc;
char            *argv[];

{
  char ch;

  struct VAR    *root;
  struct VAR    *current;
  
  static int    env_size = 128; /* This may change with future O.S. vers */
  
  unsigned      environment;
  unsigned      index;
  unsigned      segment;

  int           current_size;
  int           counter;
  int           result;
  int           correct_length;

  char          variables[512];
  char          line[81];
  char          number[20];
  char          *ptr;

  struct SREG   segregs;
  
  segread(&segregs);
  segment = segregs.cs - 0x10;
  environment = peek(segment,0x2c);
  for (index = 0; index <= env_size; index ++)
    variables[index] = (char)peek(environment, index);

  root = alloc(sizeof(struct VAR));
  current = root;

  ptr = &variables;
  do
  {
    strcpy(current->string, ptr);
    correct_length = strlen(ptr);
    ptr += (correct_length + 1);
    if (strlen(ptr) != 0)
    {
      current->link = alloc(sizeof(struct VAR));
      current = current->link;
    }
    else
      current->link = NULL;
  }
  while(current->link != NULL);


/*
** Execution continues here if no parameters are present.
** This indicates that the user wants to list the complete
** environment and then return to the command interpreter.
** Since C provides no built-in function to do this, the
** program builds each environment item into a string which
** is stored on the heap.
*/
    
  if (argc == 1)
  {
    current = root;
    do
    {
      puts(current->string);
      current = current->link;
    }
    while(current != NULL);
    putchar('\n');
    putback(root);
    exit(0);
  }

/*
** Execution continues here if the user specified one argument.
** In that case, the user wishes to examine a specific environment
** variable.  The C language built in 'getenv()' is used to ferret
** this variable from the environment.  It is then written to
** the screen.
*/

  if (argc == 2) /* request specific environment variable */
  {
  
    /*
    ** Convert the argument to upper case
    */

  
    stoupper(argv[1]);
  
    /*
    ** A leading '-' indicates that the user wishes to delete
    ** the environment variable which is specifed, rather than
    ** set an environmental variable.
    */
  
    if (argv[1][0] == '-')
    {

      /*
      ** Zero the workspace before we fill it with anything
      */
      
      for (index = 0; index < env_size; index++)
        variables[index] = '\0';
      argv[1] += 1;
      index = 0;
      current = root;
      do
      {
        if (strncmp(argv[1], current->string, strlen(argv[1])) != 0)
        {
          counter = 0;
          for (counter = 0; counter <= strlen(current->string); counter ++)
            variables[index++] = current->string[counter];
        }
        current = current->link;
      }
      while(current != NULL);
      variables[index] = '\0';

      /*
      ** Now, write the workspace back to the environment area.
      ** This should be the complete workspace, minus the variable
      ** which was to be deleted.  Since an item is being deleted,
      ** the length written back will always be less than the length
      ** obtained from the system.
      */

      for (index = 0; index <= env_size; index ++)
        poke(environment, index, (char)variables[index]);
      poke(environment, index, 0);
      putback(root);
      exit(0);
    }
    else
    {
      counter = 0;
      strcpy(line, argv[1]);
      if (ptr = getenv(argv[1]))
      {
        strcat(line, "= ");
        strcat(line, ptr);
      }
      else
        strcat(line, " was not found");
      puts(line);
      free(ptr);
      putback(root);
      exit(0);
    }
  }

/*
** Execution continues here if the user wishes to add or modify
** one of the environment variables.  In this case, the new or
** modified variable is read from the command line and placed
** in the environment.  Checks are made to determine if the
** new environment variable will properly fit into the space
** allocated by the operating system for the environment.  If
** space is not available, the routine will indicate an error
** message and return without modifying the environment.
*/

  if (argc > 2)
  {

    /*
    ** Convert the environment variable name to upper case
    */

    stoupper(argv[1]);

    /* Find out if the variable has already been defined.
    ** If so, use the record that defines it.  Otherwise,
    ** create a new record and fill it in.  Comparison will
    ** return zero if a variable with the same name is found.
    ** current will be pointing to it.  This loop will test
    ** all but the last record in the linked list.  If we drop
    ** through the loop with a zero result, the comparison found
    ** something, and the current pointer points at the structure
    ** containing the match.  If the result is non zero, then
    ** we have not found a match and we must test the last
    ** record in the linked list.
    */

    current = root;
    do
    {
      if ((result = strncmp(current->string, argv[1], strlen(argv[1]))) == 0)
        break;
      else
        if (current->link != NULL)
          current = current->link;
    }
    while (current->link != NULL);

    /*
    ** Now, we must test the last item in the linked list.  Do so
    ** only if the result from the loop was nonzero.
    */
    
    if (result != 0)
      (result = strncmp(current->string, argv[1], strlen(argv[1])));
    
    /*
    ** If no match was found, then allocate sufficient space
    ** for a new record.  Otherwise, result will be zero and
    ** you will fall through to the actual building of the
    ** string
    */
    
    if (result != 0) 
    {
      current->link = alloc(sizeof(struct VAR));
      current = current->link;
      current->link = NULL;
    }
    
    /*
    ** Now that we have space reserved to take the new variable,
    ** copy the arguments passed via the command line.  The first
    ** argument is considered the variable name.  All others are
    ** considered the assignments.  The routine will place an
    ** ascii space between adjacent arguments, allowing each to
    ** represent a different assignment.
    */
    
    strcpy(current->string, argv[1]);
    strcat(current->string, "=");
    index = 2; /* new environment starts at argv[2] */
    while (index < argc)
    {
      stoupper(argv[index]);
      strcat(current->string, argv[index++]);
      strcat(current->string, " ");
    }

    /*
    ** When the loop is exited, an unwanted space character will
    ** trail the last variable definition.  The following line
    ** removes that trailing space.
    */

    correct_length = strlen(current->string) -1;
    current->string[correct_length] = '\0';

    /*
    ** Now that we have the variable assigned within the record,
    ** we copy each record in the list to the workspace.  Note
    ** that the workspace is intentionally larger than the default
    ** environment area provided by Concurrent DOS.  The idea here
    ** is to copy the user's input correctly, then determine if there
    ** is sufficient room in the environment to copy it all.  If there
    ** is, copy poke the workspace into the environment area.
    ** Otherwise, write a 'too bad' message and go home.
    */

    for (index = 0; index < env_size; index++)
      variables[index] = '\0';  
    
    current = root;
    index = 0;
    do
    {
      counter = 0;
      for (counter = 0; counter <= strlen(current->string); counter ++)
        variables[index++] = current->string[counter];
      current = current->link;
    }
    while(current != NULL);
    variables[index] = '\0';

    if (index >= env_size)
    {
      strcpy(line, argv[1]);
      strcat(line, " too large for environment!");
      puts(line);
      puts("Exiting with no environment change");
      putback(root);
      exit(-1);
    }
    else
    {
      strcpy(line, "Unused environment: ");
      itoa(number, (env_size - index));
      strcat(line, number);
      strcat(line, " Bytes");
      puts(line);
      
      for (index = 0; index <= env_size; index ++)
        poke(environment, index, (char)variables[index]);
      poke(environment, index, 0);
      putback(root);
      exit(0);
    }
  }
}

root);
      exit(-1);
    }
    else
    {
      strcpy(line, "Unused environment: ");
      itoa(number, (env_size - ind��������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������������
#include "stdio.h"
#define LENGTH 501
#define linelen 80
#define PI 3.14159265359
double tstep = .1;
double ampl=1.0;
static double efac=1.0;
/*************************************/
double kay1(t,x,phase)
double t,x,phase;
{double rhs();
 double y;
 extern double tstep;
 extern double ampl;
 y=efac*efac*ampl;
/*printf("In kay1 rhs multiplication factor = %g\n",y);/**/
 y = y*rhs(t,x,phase);
/* printf("\n rhs = %g",y);/**/
 y= tstep*y;
/*printf("kay1 returning %g",y);/**/
 return(y);
}
/*****************************************/
double kay2(t,x,xprime,phase)
double t,x,xprime,phase;
{extern double tstep;
  extern double ampl;
 double rhs();
double kay1();
double y,z,w;
y=t + tstep/2.;
/*printf("\nin kay2 y = %g",y);/**/
z=x + tstep*xprime/2.;
/*printf("   z = %g",z);/**/
z = z + tstep*kay1(t,x,phase)/8.;
/*printf(" after adding k1 z = %g",z);/**/
w=efac*efac*ampl;
/*printf("In kay2 rhs m. f. = %g\n",w);/**/
w = w*rhs(y,z,phase);
/*printf("\n w = %g",w);/**/
w=w*tstep;
/*printf(" kay2 returning %g",w);/**/
return(w);
}
/*********************************************/
double kay3(t,x,xprime,phase)
double t,x,xprime,phase;
{extern double tstep;
  extern double ampl;
 double rhs();
 double kay2();
double y,z,w;
 y= t + tstep;
/*printf("\n in kay3 y = %g",y);/**/
 z = x + tstep*xprime;
/*printf("  z = %g",z);/**/
 z = z + tstep*kay2(t,x,xprime,phase)/2.;
/*printf("  after adding k2 z = %g",z);/**/
 w=efac*efac*ampl;
/*printf("In kay3 rhs m. f. = %g\n",w);/**/
 w = w*rhs(y,z,phase);
/*printf("\n w = %g",w);/**/
 w = w*tstep;
/*printf("  kay3 returning %g",w);/**/
 return(w);
}
/********************************************/
double upx(t,x,xprime,phase)
double t,x,xprime,phase;
{extern double tstep;
 double y;
 double kay1(),kay2();
/*printf("\narguments passed to upx are t=%g,x=%g,x'=%g,phase=%g\n",t,x,xprime,phase);/**/
 y = kay1(t,x,phase) + 2.*kay2(t,x,xprime,phase);
/* printf("\n in upx y = %g",y);/**/
 y = xprime + y/6.;
/*printf(" then y = %g",y);/**/
 y = x + tstep*y;
/*printf(" and %g is returned",y);/**/
 return(y);
}
/*******************************************/
double upxprime(t,x,xprime,phase)
double t,x,xprime,phase;
{extern double tstep;
 double y;
 double kay1(),kay2(),kay3();
/*printf("\narguments passed to upxprime are t=%g,x=%g,x'=%g,phase=%g\n",t,x,xprime,phase);/**/
 y = (kay1(t,x,phase) + kay3(t,x,xprime,phase))/6.;
/*printf("\n in upxprime y = %g",y);/**/
 y = y + 2.*kay2(t,x,xprime,phase)/3.;
/*printf(" then y = %g",y);/**/
 y = y + xprime;
/*printf(" and %g is returned",y);/**/
 return(y);
}
/***********************************************/
stepit(limit,t0,x0,x0prime,phase)
int limit;
double t0,x0,x0prime,phase;
{double X[LENGTH],Xprime[LENGTH];
 double force[LENGTH],t[LENGTH];
 extern double tstep;
 int n;
 double upx(),upxprime();
 X[0]=x0;
Xprime[0]=x0prime;
t[0]=t0;
for(n=0;n<limit;n++)
{/*printf("\n passing arguments t = %g,x= %g,x'=%g,phase=%g\n",t[n],X[n],Xprime[n],phase);/**/
force[n]=rhs(t[n],X[n],phase);
X[n+1]=upx(t[n],X[n],Xprime[n],phase);
 Xprime[n+1]=upxprime(t[n],X[n],Xprime[n],phase);
 t[n+1]= t[n] + tstep;
printf("\n At t = %g, X = %g, X' = %g\n",t[n+1],X[n+1],Xprime[n+1]/efac);/**/
 }
wrtfile(limit,t,X,Xprime,force,1);
}
/*********************************************/
main(argc,argv)
int argc;
char *argv[];
{int i;
 double atof();
 int atoi();
extern double dklen;
extern double tstep;
extern double ampl;
  double efactor();
 double t0,x0,xprime, phz;
char linebuf[linelen];
int c;
 i = atoi(argv[1]);
if(i>500) {i=500;printf("\nMaximum number of time steps allowed is 500.\n");}
printf("\n The number of time steps will be %d\n",i);
printf("Enter the value of the decay length for this run-\n");
dkin:c = getaline(linebuf,80);
if (c>=1) dklen = atof(linebuf);
if(dklen<=0.) 
{printf("\nAn illegal value of the decay length,%g, has been entered.\n",dklen);
 printf("The decay length must be positive!  Reenter-\n");
             goto dkin;}
if(dklen >=1.e3) {printf("\n Largest value of decay length allowed is 1. E3.");
                  dklen = 1.e3;}
printf("\n The value of the decay length for this run is %g",dklen);
printf("\nEnter the potential amplitude for this run-\n");
c=getaline(linebuf,linelen);
if(c>=1) ampl=atof(linebuf);
printf("The potential amplitude for this run is %g\n",ampl);
printf("Enter epsilon value for this run-\n");
c=getaline(linebuf,linelen);
if(c>=1) efac=efactor(atof(linebuf));
printf("The value of epsilon for this run is %g\n",atof(linebuf));
t0=0.0; /* default initial time */
printf("\n Enter the initial time for this run -\n");
c=getaline(linebuf,linelen);
if(c>=1) t0=atof(linebuf);
printf("\n The initial time for this run is %g\n",t0);
printf("\n Enter the time step to be used for this run -\n");
c=getaline(linebuf,linelen);
if(c>=1) tstep=atof(linebuf);
printf("\n The time step to be used for this run is %g\n",tstep);
x0=0.0; /* default initial position */
printf("\n Enter the initial position for this run -\n");
c=getaline(linebuf,linelen);
if(c>=1) x0=atof(linebuf);
printf("\n The initial position for this run is %g\n",x0);
xprime=1.0; /* defalult initial velocity */
printf("\n Enter initial velocity (in units of the thermal velocity) for this run -\n");
c=getaline(linebuf,linelen);
if(c>=1) xprime=efac*atof(linebuf);
printf("\n The initial velocity for this run is %g\n",atof(linebuf));
phz=0.0; /* default wave phase */
printf("\n Enter the wave phase (in units of pi) for this run -\n");
c=getaline(linebuf,linelen);
if(c>=1) phz=PI*atof(linebuf);
printf("\n The wave phase for this run is %g\n",phz);
stepit(i,t0,x0,xprime,phz);
}
/*************************************************/
getaline(s,lim)
char s[];
int lim;
{int c,i;
 for (i=0;i<lim-1&&(c=getchar())!=EOF&&c!='\n';++i)
  s[i]=c;
if(c=='\n') {s[i]=c;++i;}
s[i]='\0';
if(i>=lim) {printf("\n Line length limit of %d characters exceeded\n",lim);
               return(0);}
return(i-1);
}
/**************************************************/
double efactor(x)
double x;
{double log();
 double exp();
 double y;
if(x<=0) x=1.0;/* default value of epsilon if none entered */
printf("The value of epsilon in efactor is %g\n",x);/**/
 y=log(x)/3.;
 y=exp(y);
printf("efac is calculated to be %g\n",y);/**/
 return(y);
 }
/**************************************************/
wrtfile(len,px,parg1,parg2,parg3,mode)
int len,mode;
double *px,*parg1,*parg2,*parg3;
{extern FILE *fopen();
 extern char *calloc();
 FILE *strmptr;
 char *buff;
 double *pb;
 int i;
/*printf("\n In wrtfile mode = %d",mode);*/
if (!mode) {strmptr = fopen("a:data.mc0","wb");
/*           printf("\n Opening data file in write mode");*/}
  else {strmptr = fopen("a:data.mc0","ab");
/*                printf("\nOpening file in append mode");*/}
if(strmptr==NULL) {printf(" Could not open the file a:data1.sin");
       exit(0);}
buff = calloc(32,1);
for (i=0;i<len;i++)
{ pb = buff;
  *pb = *(px +i);
  pb = buff + 8;
  *pb = *(parg1 + i);
  pb = buff + 16;
  *pb = *(parg2 + i);
  pb = buff + 24;
  *pb= *(parg3 + i);
fwrite(buff,1,32,strmptr);
}
fclose(strmptr);
}
/*************************************************/

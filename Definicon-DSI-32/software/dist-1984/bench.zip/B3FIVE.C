#include "math.h"
#include "limits.h"
#include "stdio.h"
#define MAXTERM 100
#define EPSILON 1.e-4
/************************/
double dklen = 1.e3;
static double c1=.35502805;
static double c2=.25881940;
static double root3=1.732051;
static double ROOTPI=1.772453850905516;
static double PI=3.1415926535897933;
static double deltab = .003897;
static double deltaa = .000;
static double ac1 = 3.*5./216.;
static double twothrds=2./3.;
/***************************/
int _stack =20480;
/***************************/
double termf(k,z)
double z;
int k;
{double x;
int j;
int chk;
x=1.0;
chk=3*(k-1) + 1;
/*printf("\nin termf k = %d, z= %f",k,z);/**/
if(k==0) return(x);
for(j=chk;j<=(3*k);j++)
{if(j==chk) x=z;
  else x=x*z/j;
/*printf("\n in termf j = %d, x = %f\n",j,x);/**/
}
return(x);
}
/*******************************************/
double termg(k,z)
double z;
int k;
{double x;
int j;
int chk;
chk=3*(k-1) + 1;
x=z;
/*printf("\nin termg k = %d, z= %f,x = %f",k,z,x);/**/
if(k==0) return(x);
for(j=chk;j<=(3*k);j++)
{if(j==chk) x=z;
   else x=x*z/(j+1);
/*printf("\n in termg j = %d, x = %f\n",j,x);/**/
}
return(x);
}
/*******************************************/
double funcf(z)
double z;
{double termf();
 double x,y;
 double test,w;
 int k;
 y=0.;
 x=1.;
 for(k=0;k<MAXTERM;k++)
  {/*printf("\npassing argument z = %g to termf\n",z);/**/
    w=termf(k,z);
    x=x*w;
   /*printf("\n termf = %f, for k=%d\n",x,k);/**/
   y=y+x;
/*printf("\n for k=%d, y = %f,x = %f\n",k,y,x);/**/
    test=(x<0.)?-x:x;
/*printf("\n Before testing with epsilon x = %g\n",x);/**/
   if(test<=EPSILON) return(y);
  }
printf("\n  No convergence after MAXTERM terms - breaking off\n");
 return(0);
}
/*******************************************/
double funcg(z)
double z;
{double termg();
 double x,y;
 double test,w;
 int k;
 y=0.;
 x=1.;
 for(k=0;k<MAXTERM;k++)
  {w=termg(k,z);
   x=x*w;
   /*printf("\n termg = %f, for k=%d\n",x,k);/**/
   y=y+x;
/*printf("\n for k=%d, y = %f,x = %f\n",k,y,x);/**/
    test=(x<0.)?-x:x;
/*printf("\n before comparing with epsilon in funcg x = %g\n",x);/**/
   if(test<=EPSILON) return(y);
  }
printf("\n  No convergence in funcg after MAXTERM terms - breaking off\n");
 return(0);
}
/*******************************************/
double Aiminus(f,g)
double f,g;
 {
 double x,y;
 x= c2*g;
/*printf("\n for z = %.1g,function g term = %g",x);/**/
 y= c1*f;
 /*printf(" function f term =%g",y);/**/
 x= y - x;
 return(x);
}
/*******************************************/
double Biminus(f,g)
double f,g;
 {
 double x,y;
 x= c2*g;
/*printf("\n for z = %.1g,function g term = %g",x);/**/
 y= c1*f;
 /*printf(" function f term =%g",y);/**/
 x= y + x;
 x=x*root3;
 return(x);
}
/*************************************************/
double Biasym(z)
double z;
{double cos();
 double sqrt(),exp();
 double arg,rootz,zeta;
 double term1,term2,sum;
/*printf("\nin Biasym z = %g",z);/**/
 sum=(z<0.)?-z:z;
 rootz=sqrt(sum);
/*printf(", rootz = %g",rootz);/**/
 zeta=twothrds*sum*rootz;
/*printf(", and zeta = %g\n",zeta);/**/
  if(z>0.) /* asymptotic expansion for positive z */
      {term1=1.-ac1/zeta;
       term2=exp(zeta);
       sum=1./ROOTPI;
       sum=sum/rootz/rootz;
       sum=sum*term1*term2;
       return(sum);
      }
 arg=zeta + PI/4. + deltab * (-10./z);
/*printf(" The argument of the trig functions = %g",arg);/**/
 term1=cos(arg);
/*printf(", and cos = %g\n",term1);/**/
 sum = term1 ;
/*printf(" Before division by rootpi and root of rootz sum = %g\n",sum);/**/
 sum=sum/ROOTPI;
 sum=sum/sqrt(rootz);
/*printf(" Biasym returning the value %g\n",sum);/**/
return(sum);
}
/*******************************************************/
double Aiasym(z)
double z;
{double cos(),sin();
 double sqrt(),exp();
 double arg,rootz,zeta;
 double term1,term2,sum;
/*printf("\nin Aiasym z = %g",z);/**/
 sum=(z<0.)?-z:z;
 rootz=sqrt(sum);
/*printf(", rootz = %g",rootz);/**/
 zeta=twothrds*sum*rootz;
/*printf(", and zeta = %g\n",zeta);/**/
 if (z>0.) /* asymtotic expansion for z positive */
     {term1=1.-ac1/zeta;
/*printf(" term1 = %g",term1);/**/
      term2=exp(-zeta);
/*printf("  term2 = %g",term2);/**/
      sum=.5/ROOTPI;
      sum=sum/rootz/rootz;
/*printf("   sum = %g\n",sum);/**/
      sum=sum*term1*term2;
/*printf(" returning value of %g",sum);/**/
      return(sum);
     }
 arg=zeta + PI/4. + deltaa *(-10.)/z;
/*printf(" The argument of the trig functions = %g",arg);/**/
 term2=cos(arg);
 term1=sin(arg);
/*printf(", and cos = %g, sin = %g\n",term1,term2);/**/
 sum = term1 - ac1*term2/zeta;
/*printf(" Before division by rootpi and root of rootz sum = %g\n",sum);/**/
 sum=sum/ROOTPI;
 sum=sum/sqrt(rootz);
/*printf(" Aiasym returning the value %g\n",sum);/**/
return(sum);
}
/*******************************************************/
double seriesh(pz,n)
double *pz;
int n;
{double x;
   int j;
   x=1.;
/*printf("\n  ** In seriesh **\n ");/**/
 for (j=1;j<n;j++)
   { x= 1. + x/(*(pz+j));
/*printf(" For j= %d,  C[j] = %g, x = %g \n",j,(*(pz+j)),x);/**/
   }
  return(x);
  }
/***********************************************/
double fterm(A,n)
double A[];
int n;
  { double x;
  int j,k,N;
  N =n-1;
 while (( j= (N-1)/2)>=0)
  {/*printf("  in fterm N = %d, j = %d \n",N,j);/**/
    for (k=0;k<=j;k++)
    { if (N>1) { x = A[N-k]*A[k]; A[k]=x;
                /*printf("k = %d, x = %g\n",k,x);/**/
                }
     }
    N=N/2;
  if(N<=1) break;
  }
x=A[1]*A[0];
return(x);
}
/************************************************/
double starth(z,pterm,pN)
double z;
double *pterm;
int *pN;
{double C[MAXTERM];
 double x,y,z3;
 int j,N;
 double sqrt();
 double seriesh(),fterm();
 z3 = z*z*z;
 y=(z3<0.)?-z3:z3;
 N= 2.*sqrt(y)/3. + 1.;/*select N so that middle term of series is */ 
 *pN=N;                   /*   of order unity  */
/*printf(" In starth - z3 = %g, N = %d\n",z3,N);/**/
 if(N==1)  {*pterm = 1.;*pN=0;return(0);}
 C[0]= .5*z*z;
 for (j=1;j<N;j++)
   {y = z3/(3*j+2); C[j] = y/(3*j+1);
/*printf(" For j= %d, C[j] = %g\n",j,C[j]);/**/
   }
 x=seriesh(C,N);
 y=fterm(C,N);
/*printf(" \n seriesh returned %g to starth, fterm returned %g\n",x,y);/**/
 x=x*y;
 *pterm = y;
 return(x);
}
/***********************************************/
double B3real(z)
double z;
{double Bi(),funch();
  double x,y,w;
  if(z< -5.){w= -1./z;return(w);}
  y = Bi(-z);
/*printf("\n In B3real, Bi term = %g\n",y);/**/
 x=PI*y/3.;
 if(z>11.) w=1./z-2.*x;
   else w=funch(-z);
/*printf(" Function h term = %g\n",w);/**/
 x=x-w;
 return(x);
}
/************************************************/
double B3imag(z)
double z;
{double Ai();
 double x;
  x=PI*Ai(-z);
return(x);
}
/**********************************************/
double termh(k,z)
int k;
double z;
{double x;
 int j;
 int chk;
 if(k==0) {x=z*z/2.;return(x);}
 chk=3.*(k-1)+1.;
 x=z;
/*printf("\n In termh k= %d, z= %g",k,z);/**/
 for (j=chk;j<=(3*k);j++)
  {if(j==chk) x=z;
   else x=x*z/(j+2);
/*printf("\n j = %d,x= %g",j,x);/**/
  }
 return(x);
}
/***************************************************/
double funch(z)
double z;
{ double termh(),starth();
 double x,y,w,test;
 double *pterm;
 int *pN;
 int k;
 y=starth(z,pterm,pN);
 x= *pterm;
 for(k= *pN;k<MAXTERM;k++)
   {/*printf("\n Passing argument z+%g to termh\n",z);/**/
    w=termh(k,z);
    x=x*w;
    /*printf("\n termh = %g for k= %d\n",w,k);/**/
    y=y+x;
    /*printf("For k= %d, y= %g, x= %g\n",k,y,x);/**/
    test=(x<0.)?-x:x;
/*printf(" Before comparing with epsilon in testh test=%g\n",test);/**/
    if(test<=EPSILON) return(y);
   }
 printf("No convergence in termh after %d terms\n",MAXTERM);
 return(0);
}
/****************************************************/
double rhs(t,x,phase)
double t,x,phase;
{double B3real(),B3imag();
 double cos(),sin(),exp();
 double y,z,w;
extern double dklen;
 y=t+phase;
 /*printf("Argument of cos in rhs = %g\n",y);/**/
 z=cos(y);
 w=sin(y);
/*printf(" value of cos = %g\n",z);/**/
 y=B3real(x);
/*printf(" Value of B3real = %g\n",y);/**/
 z=z*y;
/*printf(" Value of sin in rhs = %g\n",w);/**/
 y=B3imag(x);
/*printf(" Value of B3imag =%g\n",y);/**/
 w=w*y;
 z=z+w;
if(dklen < 1.e3)
{if(x>0.) w=x/dklen;
   else w = 0.;
z = z*exp(-w);}
/*printf(" Value of total function is %g\n",z);/**/
 return(z);
}
/*****************************************/
double Ai(z)
double z;
{double Aiminus(),Aiasym();
 double funcf(),funcg();
 double x,u;
 double f,g;
 if(z>5.||z<-10.) {x=Aiasym(z);return(x);}
 f=funcf(z);
 g=funcg(z);
 x=Aiminus(f,g);
 return(x);
}
/******************************************/
double Bi(z)
double z;
{ double Biminus(),Biasym();
  double x,y;
  double f,g;
  double funcf(),funcg();
  y=(z<0.)?-z:z;
  if(y>10.)
   {x=Biasym(z);return(x);}
  f=funcf(z);
  g=funcg(z);
  x=Biminus(f,g);
  return(x);
}
/***********************************/

#ifdef SETJMP
#include <signal.h>
#include <setjmp.h>
#endif

int errnum;
int *_disply[32];
int _argc;
char **_argv;
int argindex;
int argnum;

#ifndef VMSHOST
#ifdef GHCC
rescan(pc)
char *pc;
{
    argindex = 0;
    argnum = 0;
    do
	rchar(pc);
    while (*pc != ' ' && *pc != '\t' && *pc != '\n');
}

rchar(pc)
char *pc;
{
    if (argnum < _argc)
	if ((*pc = _argv[argnum][argindex++]) == '\0') {
	    argindex = 0;
	    if (++argnum < _argc)
		*pc = ' ';
	}
    if (argnum >= _argc)
	*pc = '\n';
}

#endif
exitx(x)
int x;
{
    __exit(x);
    }

#endif

xcreat(channel, name, mode)
char *name;
{
#ifdef VMSHOST
    return(creat(channel, name, mode));
#else
    return(creat(name, mode));
#endif
}

#ifdef VMSHOST
unlink()
{
}
#endif

#ifndef VMSHOST
UNWIND()
{
    check(0);
}

ERROR()
{
    check(0);
}

CASERNG()
{
    check(0);
}

FCALL()
{
}

PCSTART()
{
}

PCEXIT()
{
    _exit(0);
}
#endif
#ifdef SETJMP
jmp_buf jmpbuf;

fpecatch()
{
    longjmp(jmpbuf, 1);
}
#endif
double hostatof(s)
char *s;
{
double atof();
double ret;

#ifdef SETJMP
    if (setjmp(jmpbuf))
	ret = 0.0;
    else {
	signal(SIGFPE, fpecatch);
#endif
	ret = atof(s);
#ifdef SETJMP
    }
    signal(SIGFPE, SIG_DFL);
#endif
    return(ret);
}

rsha(i, j)
{
    if (i >= 32 || i <= -32)
/* 16000 doesn't do shift by 32 correctly */
	if (j >= 0 || i <= -32)
	    return (0);
	else
	    return (-1);
    else
	return(j >> i);
}

rsh(i, j)
unsigned j;
{
    if (i >= 32 || i <= -32)
/* 16000 doesn't do shift by 32 correctly */
	return (0);
    else
	return(j >> i);
}

lsh(i, j)
{
    if (i >= 32 || i <= -32)
/* 16000 doesn't do shift by 32 correctly */
	return (0);
    else
	return(j << i);
}

booland(x,y)
{
    return (x & y);
}

boolor(x,y)
{
    return (x | y);
}

boolxor(x,y)
{
    return (x ^ y);
}

outdhex( d ) double d ; {
    register char *pt, *end ;
    register int ch ;

    end = ((char *) &d)-1;
    pt = end+sizeof( double );
    while ( pt != end ) {
	ch = (unsigned char) *(pt--);
	if ( (ch>>4)>9 )
	    putchar( (ch>>4)+('A'-10) );	/*pascal proc, not macro*/
	else
	    putchar( (ch>>4)+'0' );
	if ( (ch&0xf)>9 )
	    putchar( (ch&0xf)+('A'-10) );
	else
	    putchar( (ch&0xf)+'0' );
    }
}

/********   NEW    ********/

#define NULL 0
#define SIZE 4096
#define TRUE 1

int domark = TRUE;
char *malloc();

struct list {struct list *next, *last; int left; char data[1]} *freelist = NULL;

DISPOSE(ptr, size)
char *ptr;
{
}

_NEW(ptr, size)
char **ptr;
{
    if ((*ptr = malloc((unsigned)size)) == 0) {
	write(2, "Out of memory\n", 14);
	stop();
    }
}

NEW(ptr, size)
char **ptr;
{
    if (!domark)
	_NEW(ptr, size);
    else {
	if (freelist == NULL) {
	    _NEW((char **)&freelist, SIZE + (freelist->data-(char *)freelist));
	    freelist->last = NULL;
	    freelist->next = NULL;
	    freelist->left = SIZE;
	}
	if (size > freelist->left) {
	    if (freelist->next == NULL) {
		_NEW((char **)&freelist->next,
		     SIZE + (freelist->data - (char *)freelist));
		freelist->next->next = NULL;
		freelist->next->last = freelist;
	    }
	    freelist = freelist->next;
	    freelist->left = SIZE;
	}
	*ptr = freelist->data + (SIZE - freelist->left);
	freelist->left -= size;
	if ((int)*ptr == 0x2ea08)
	     xxx();
/*	printf("ptr: %x, %x, %d\n", *ptr, *((int *)(&ptr-2)), size); */
    }
}

xxx()
{}

enablemark(en)
{
     int oldmark = domark;

     domark = en;
     return(oldmark);
}

mark(addr)
struct list **addr;
{
    NEW((char **)addr, sizeof(struct list));
    (*addr)->last = freelist;
    (*addr)->left = freelist->left+sizeof(struct list);
}

release(addr)
struct list *addr;
{
    freelist = addr->last;
    freelist->left = addr->left;
}

#ifndef VMSHOST
/******		MALLOC		******/

extern char end;
static char *freeptr = 0;
static char *endofmem = 0;

char *brk();
char *sbrk();

char *malloc(size)
unsigned size;
{
    if (freeptr == 0) {
	freeptr = sbrk(0);
	endofmem = freeptr;
    }
    freeptr = (char *)((int)(freeptr + 1) &~ 1);   /* return even address */
    freeptr += size;
    if (freeptr > endofmem) {
	endofmem = (char *)(((int)freeptr + 0xFFF) &~ 0xFFF);
	if (brk(endofmem) == (char *)-1)
	    return((char *)0);
    }
    return(freeptr - size);
}

char *free(ptr)
char *ptr;
{
    return((char *)0);
}

char *realloc(ptr, size)
char *ptr;
unsigned size;
{
    check(0);
}
#endif

__exit()
{
#ifdef VMSHOST
    _exit(0);
#else
    exit(0);
#endif
}

/* close.c 4.2 83/06/30 */

#include "SYS.h"

SYSCALL(close)
	ret


	movl	r0,_errno
	mnegl	$1,r0
	ret
mp	cerror
p)
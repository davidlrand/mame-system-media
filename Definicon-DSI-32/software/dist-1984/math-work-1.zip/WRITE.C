/* write.c 4.1 82/12/04 */

#include "SYS.h"

SYSCALL(write)
	ret


#define	PSEUDO(x,y)	ENTRY(x); chmk $SYS_/**/y
#def
#include <errno.h>
#include <mth.h>
#define fabs(x) ((x) < 0.0 ? -(x) : (x))

#define internal static
#define and	&&
#define or	||
#define not	!
#define FALSE	0
#define TRUE	1

extern int errno ;

/* the following routines are included:
	jn(n,x)		;nth bessel function at x
	j0(x)		;0th bessel function at x
	j1(x)		;1st bessel function at x
	yn(n,x)		;nth bessel function of second kind at x
	y0(x)		;0th bessel function of second kind at x
	y1(x)		;1st bessel function of second kind at x
	erf(x)		;error function at x
	erfc(x)		;complimentary error function at x
	exp(x)		;e^x
	log(x)		;natural log of x
	log10(x)	;log base 10 of x
	sqrt(x)		;square root of x
	pow(x,y)	;x^y
	sinh(x)		;hyperbolic sine of x
	cosh(x)		;hyperbolic cosine of x
	tanh(x)		;hyperbolic tangent of x
	sin(x)		;sine of x
	cos(x)		;cosine of x
	tan(x)		;tangent of x
	asin(x)		;arc sine of x
	acos(x)		;arc cosine of x
	atan(x)		;arc tangent of x
	atan2(y,x)	;arc tangent of y/x with overflow protection,
			; and checks to see that the result is -PI to PI
	gamma(x)	;Returns the log of the absolute value of the
			; gamma function, the sign is in extern int signgam ;
	floor(x)	;Returns the largest integer not larger than x
	ceil(x)		;Returns the smallest integer not smaller than x
	fmod(x,y)	;Returns the x-floor(x/y)*y
	abs(x)		;Returns absolute value of x (int)
	fabs(x)		;Returns absolute value of x (double)
	hypot(x,y)	;Returns distance between (x,y) and (0,0), avoids
			;overflow
(there is also a random number generater in crtlib.c that returns an int)
*/
/* the following are included for internal use:
	frexp(x,&exp)	;Returns fraction part of x, sets exp to exponant
	faddexp(x,exp)	;Adds exp to the exponant of x, checks for overflow
*/
/* I do not have the following routine defined in the SYSTEM 5 manual as
 part of the math package.
	matherr(x)	;defines error behavior
*/
/* the error returns are not the same as those in the manual.  I did try to
set errno when appropriate.
*/

double log10(x) register double x;
{
    double log();
    return log(x)*0.43429448190325182765;
}

double pow( x, y ) register double x, y ; {
    register double result ; double log(), exp(), floor();
    register double zero = 0.0;

    if ( floor(y) == y ) {
	result = 1.0 ;
	if ( x == zero and y <= zero ) {
	    errno = EDOM ;
return( 1.0 );
	}
	while ( y > zero ) {
	    result *= x ;
	    y--;
	}
	while ( y < zero ) {
	    result /= x ;
	    y++;
	}
return( result );
    } else if ( x <= zero ) {
	errno = EDOM ;
return( zero );
    } else {
return( exp( y*log( x )));
    }
}

double sinh( x ) double x ; {
    double sign = 1., temp, xsq ;
    double exp();
    /* for abs(x) > MAXE then the exp(-x) term is negligable and need not
    	be evaluated, for x<.5 subtracting 2 numbers need 1 causes some loss
	of accuracy so I use a rational approximation found in HART 2029,
	otherwise I just use the obvious (expx-exp-x)/2
    */

    if ( x < 0 ) {
	sign = -1. ;
	x = -x ;
    }
    if ( x > MAXE )
return( sign*exp(x)/2. );
    else if ( x > .5 )
return( sign*(exp(x)-exp(-x))/2. );

    xsq = x*x ;
    temp = (((  -.2630563213397497062819489e2)*xsq+
		-.2894211355989563807384660366e4)*xsq+
/* berkley uses -.2894211355989563807284660366e4 instead */
		-.8991272022039509355398013511e5)*xsq+
		-.6307673640497716991184787251e6 ;

    temp /= (( xsq+
		-.173678953558233699533450911e3)*xsq+
		 .1521517378790019070696485176e5)*xsq+
		-.6307673640497716991212077277e6 ;
return( sign*temp*x );
}

double cosh(x) double x ; {
    double exp();
    /* here the only cute trick is to avoid evaluating exp(-x) if x>MAXE */

    if ( x < 0. ) x = -x ;

    if ( x > MAXE )
return( exp(x)/2 );

return( (exp(x)+exp(-x))/2. );
}

double tanh( x ) double x ; {
    /* again, the only trick here is that x>MAXE sinh==cosh */
    double sinh(), cosh();

    if ( x < -MAXE )
return( -1. );
    else if ( x > MAXE )
return( 1. );
    else
return( sinh( x )/cosh( x ));
}

/* sin of x for x [0,PI/2], stolen from Hart 3370 */
internal double _sin(x) double x ; {
    register double sum=0.0, x_square, mul ;
    register int i ;

    x /= PI2 ;
    x_square = x*x ;
    sum =x*(	0.1357884097877375669092680013e8+x_square*(
		-.4942908100902844161158627070e7+x_square*(
		0.4401030535375266501944918132e6+x_square*(
		-.138472724998245287305445709e5+x_square*
		0.1459688406665768722226959e3))));
    sum /=	0.8644558652922534429915149436e7+x_square*(
		0.4081792252343299749395778676e6+x_square*(
		0.9463096101538208180571257e4+x_square*(
		0.1326534908786136358911494e3+x_square)));
return( sum );
}

double cotan(x)
register double x;
{
    register double y, tansub();
	
    y = fabs(x);
    if (y < 1.0/HUGE_VAL) {
	errno = ERANGE;
	if (x < 0.0)
	    return(-HUGE_VAL);
	else
	    return(HUGE_VAL);
    }
    return(tansub(x,y,2));
}

#define P1 -0.13338350006421960681e+0
#define P2 +0.34248878235890589960e-2
#define P3 -0.17861707342254426711e-4
#define Q0 1.0
#define Q1 -0.46671683339755294240e+0
#define Q2 0.25663832289440112864e-1
#define Q3 -0.31181531907010027307e-3
#define Q4 0.49819433993786512270e-6

#define P(f,g) (((P3 * g P2) * g P1)* g * f + f)
#define Q(g) ((((Q4*g Q3)*g + Q2)*g Q1)*g + Q0)

#define YMAX 6.74652e09

static double tansub(x, y, flag)
register double x,y;
register int flag;
{
    register double f, g, modf();
    register double xnum, xden, xtemp;
    double xn;
	
    if (y > YMAX) {
	errno = ERANGE;
	return(0.0);
    }
    if (modf(x*0.63661977236758134308, &xn) >= 0.5)
	xn += (x < 0.0) ? -1.0 : 1.0;
    f = (x - xn*1.57080078125) + xn*4.454455103380768678308e-6;
    if ((fabs(f)) < 2.33e-10) {
	xnum = f;
	xden = 1.0;
    } else {
	g = f*f;
	xnum = P(f,g);
	xden =  Q(g);
    }
    flag |= ((int)xn & 1);
    switch (flag) {
	case 1:		/* A: tan, xn odd */
	    xnum = -xnum;
	case 2:		/* B: cotan, xn even */
	    return(xden/xnum);
		
	case 3:		/* C: cotan, xn odd */
	    xnum = -xnum;
	case 0:		/* D: tan, xn even */
	    return(xnum/xden);
    }
    return(0.0);
}

#define MAXEXP	1023
#define MINEXP	-1022

#define PI2	1.57079632679489661923

double atan2(v,u)
register double u,v;
{
    register double f,zero=0.0, frexp(), atan();
    int vexp, uexp;

    if (u == zero) {
	if (v == zero) {
	    errno = EDOM;
	    return(zero);
	}
	return(PI2);
    }

    frexp(v, &vexp);
    frexp(u, &uexp);
    if (vexp-uexp > MAXEXP-3)	/* overflow */
	f = PI2;
    else {
	if (vexp-uexp < MINEXP+3)	/* underflow */
	    f = zero;
	else
	    f = atan(fabs(v/u));
	if (u < zero)
	    f = PI - f;
    }
    if (v < zero)
	f = -f;
    return(f);
}

double asin( x ) double x ; {
    register int neg = x<0.0 ;
    double sqrt(), atan();
    /* I use the identity that asin(x)=atan(1/sqrt(1/x^2-1)) */

    x *= x ;
    if ( x == 0.0 )
return( 0.0 );			/* arc sin(0)=0 */
    if ( x == 1.0 )
return( neg? -PI2 : PI2 );
    if ( x > 1.0 ) {
	errno = EDOM ;
return( 0.0 );
    }

    x = atan( 1.0/sqrt( 1.0/x - 1.0 ));
    if ( neg )
	x = -x ;
return( x );
}

double acos( x ) double x ; {
    register int neg = x<0.0 ;
    double sqrt(), atan();
    /* I use the identity that acos(x)=atan(sqrt(1/x^2-1)) */

    x *= x ;
    if ( x == 0.0 )
return( PI2 );			/* arc cos(0)=PI/2 */
    if ( x == 1.0 )
return( neg? PI : 0 );
    if ( x > 1.0 ) {
	errno = EDOM ;
return( 0.0 );
    }

    x = atan( sqrt( 1.0/x - 1.0 ));
    if ( neg )
	x = PI-x ;
return( x );
}

double hypot( x,y ) double x,y ; {
    /* returns the distance between (x,y) and the origin, goes to some effort
	to avoid overflow, calls sqrt()
    */
    register DOUBLE *xpt = ((DOUBLE *) &x), *ypt = ((DOUBLE *) &y);
    double sqrt(), sval ;
    int e ;

    e = (( xpt->dbl_exp > ypt->dbl_exp )? xpt->dbl_exp : ypt->dbl_exp)-EXPBASE;
    xpt->dbl_exp -= e ; ypt->dbl_exp -= e ;
    sval = sqrt( x*x+y*y );
    xpt = ((DOUBLE *) &sval);
    xpt->dbl_exp += e ;
return( sval );
}

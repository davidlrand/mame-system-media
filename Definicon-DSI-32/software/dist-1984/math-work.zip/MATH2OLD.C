#include <errno.h>
#include <mth.h>
#define fabs(x) ((x) < 0.0 ? -(x) : (x))

#define internal static
#define and	&&
#define or	||
#define not	!
#define FALSE	0
#define TRUE	1

extern int errno ;

/* the following routines are included:
	jn(n,x)		;nth bessel function at x
	j0(x)		;0th bessel function at x
	j1(x)		;1st bessel function at x
	yn(n,x)		;nth bessel function of second kind at x
	y0(x)		;0th bessel function of second kind at x
	y1(x)		;1st bessel function of second kind at x
	erf(x)		;error function at x
	erfc(x)		;complimentary error function at x
	exp(x)		;e^x
	log(x)		;natural log of x
	log10(x)	;log base 10 of x
	sqrt(x)		;square root of x
	pow(x,y)	;x^y
	sinh(x)		;hyperbolic sine of x
	cosh(x)		;hyperbolic cosine of x
	tanh(x)		;hyperbolic tangent of x
	sin(x)		;sine of x
	cos(x)		;cosine of x
	tan(x)		;tangent of x
	asin(x)		;arc sine of x
	acos(x)		;arc cosine of x
	atan(x)		;arc tangent of x
	atan2(y,x)	;arc tangent of y/x with overflow protection,
			; and checks to see that the result is -PI to PI
	gamma(x)	;Returns the log of the absolute value of the
			; gamma function, the sign is in extern int signgam ;
	floor(x)	;Returns the largest integer not larger than x
	ceil(x)		;Returns the smallest integer not smaller than x
	fmod(x,y)	;Returns the x-floor(x/y)*y
	abs(x)		;Returns absolute value of x (int)
	fabs(x)		;Returns absolute value of x (double)
	hypot(x,y)	;Returns distance between (x,y) and (0,0), avoids
			;overflow
(there is also a random number generater in crtlib.c that returns an int)
*/
/* the following are included for internal use:
	frexp(x,&exp)	;Returns fraction part of x, sets exp to exponant
	faddexp(x,exp)	;Adds exp to the exponant of x, checks for overflow
*/
/* I do not have the following routine defined in the SYSTEM 5 manual as
 part of the math package.
	matherr(x)	;defines error behavior
*/
/* the error returns are not the same as those in the manual.  I did try to
set errno when appropriate.
*/

/* all constants/coeficients from Computer Approximations by Hart et al. */
/*  for small x (<8) j0 is evaluated by JZER0 5849
	for large x (>8) j0 is evaluated by PZERO 6549 and QZERO 6949
*/
/*  for small x (<8) y0 is evaluated by YZER0 6049
	for large x (>8) y0 is evaluated by PZERO 6549 and QZERO 6949
*/


#define P0 0.249999999999999993e+0
#define P1 0.694360001511792852e-2
#define P2 0.165203300268279130e-4
#define Q0 0.500000000000000000e+0
#define Q1 0.555538666969001188e-1
#define Q2 0.495862884905441294e-3

#define P(z) ((P2*z + P1)*z + P0)
#define Q(z) ((Q2*z + Q1)*z + Q0)

#define EPS	5.551115e-17

double exp(x) register double x;
{
    register int n;
    register double xn, g, z, rt;
    double r;
    register DOUBLE *pt = &r;
	
    if (x > LOGHUGE) {
	errno = ERANGE;
	return(HUGE_VAL);
    }
    if (x < LOGTINY) {
	errno = ERANGE;
	return(0.0);
    }
    if (fabs(x) < EPS)
	return(1.0);
    
    n = z = x * 1.4426950408889634074;
    if (n < 0)
	--n;
    if (z-n >= 0.5)
	++n;
    xn = n;
    g = (x - xn*0.693359375) + xn*2.1219444005469058277e-4;
    z = g*g;
    rt = P(z)*g;
    r = 0.5 + rt/(Q(z)-rt);
    
    pt->dbl_exp += n+1;
	
    return(r);
}


/* takes the natural log of a number.  First we reduce the number to
	between sqrt(2) and 1/sqrt(2) (by removing any exponant)
	then we take the log of this, and add the exponant*LOG2
	the procedure for the log is HART 2705
*/

double log10(x) register double x;
{
    double log();
    return log(x)*0.43429448190325182765;
}

#define A0 -0.64124943423745581147e+2
#define A1 +0.16383943563021534222e+2
#define A2 -0.78956112887491257267e+0
#define A(w) ((A2*w A1)*w A0)

#define B0 -0.76949932108494879777e+3
#define B1 +0.31203222091924532844e+3
#define B2 -0.35667977739034646171e+2
#define B(w) (((w B2)*w B1)*w B0)

#define C0 0.70710678118654752440
#define C1 0.693359375
#define C2 -2.121944400546905827679e-4

double log(x) register double x;
{
    register double Rz, f, z, w, znum, zden, xn, frexp();
    int n;
	
    if (x <= 0.0) {
	errno = EDOM;
	return(-HUGE_VAL);
    }
    f = frexp(x, &n);
    if (f > C0) {
	znum = (f-0.5) - 0.5;
	zden = f*0.5 + 0.5;
    } else {
	--n;
	znum = f - 0.5;
	zden = znum*0.5 + 0.5;
    }
    z = znum/zden;
    w = z*z;
/* the lines below are split up to allow expansion of A(w) and B(w) */
    Rz = z + z * (w *
	A(w)
	/B(w));
    xn = n;
    return((xn*C2 + Rz) + xn*C1);
}


double sqrt(x) register double x ; {
    double frac, frexp();
    int exp ;
    register double y0,tf,half;
    register DOUBLE *pt = (DOUBLE *) &frac;
    
    half = 0.0; /* here we will use some register overloading... */
    if ( x <= half ) {
	if ( x < half )
	    errno = EDOM ;
return(half);
    }
    half = 0.5; /* Back to the real world */
    
    tf = frexp( x,&exp );
    
    y0 = 0.41731 + 0.59016 * tf;

    y0 = frac = (y0 + tf/y0);
    pt->dbl_exp -= 2;           /* y0 = y0 * 0.25 */
    y0 = frac + tf/y0;		/* fast calculation of y2 */

    y0 = half * (y0 + tf/y0); 
    y0 = half * (y0 + tf/y0); /* Accurate now to 63.32 bits */
    
    if (exp & 1) {
	y0 *=  0.70710678118654752440;
	exp++;
    }
    frac = y0;
    pt->dbl_exp += exp/2;
return( frac );
}

double pow( x, y ) register double x, y ; {
    register double result ; double log(), exp(), floor();
    register double zero = 0.0;

    if ( floor(y) == y ) {
	result = 1.0 ;
	if ( x == zero and y <= zero ) {
	    errno = EDOM ;
return( 1.0 );
	}
	while ( y > zero ) {
	    result *= x ;
	    y--;
	}
	while ( y < zero ) {
	    result /= x ;
	    y++;
	}
return( result );
    } else if ( x <= zero ) {
	errno = EDOM ;
return( zero );
    } else {
return( exp( y*log( x )));
    }
}

double sinh( x ) double x ; {
    double sign = 1., temp, xsq ;
    double exp();
    /* for abs(x) > MAXE then the exp(-x) term is negligable and need not
    	be evaluated, for x<.5 subtracting 2 numbers need 1 causes some loss
	of accuracy so I use a rational approximation found in HART 2029,
	otherwise I just use the obvious (expx-exp-x)/2
    */

    if ( x < 0 ) {
	sign = -1. ;
	x = -x ;
    }
    if ( x > MAXE )
return( sign*exp(x)/2. );
    else if ( x > .5 )
return( sign*(exp(x)-exp(-x))/2. );

    xsq = x*x ;
    temp = (((  -.2630563213397497062819489e2)*xsq+
		-.2894211355989563807384660366e4)*xsq+
/* berkley uses -.2894211355989563807284660366e4 instead */
		-.8991272022039509355398013511e5)*xsq+
		-.6307673640497716991184787251e6 ;

    temp /= (( xsq+
		-.173678953558233699533450911e3)*xsq+
		 .1521517378790019070696485176e5)*xsq+
		-.6307673640497716991212077277e6 ;
return( sign*temp*x );
}

double cosh(x) double x ; {
    double exp();
    /* here the only cute trick is to avoid evaluating exp(-x) if x>MAXE */

    if ( x < 0. ) x = -x ;

    if ( x > MAXE )
return( exp(x)/2 );

return( (exp(x)+exp(-x))/2. );
}

double tanh( x ) double x ; {
    /* again, the only trick here is that x>MAXE sinh==cosh */
    double sinh(), cosh();

    if ( x < -MAXE )
return( -1. );
    else if ( x > MAXE )
return( 1. );
    else
return( sinh( x )/cosh( x ));
}

/* sin of x for x [0,PI/2], stolen from Hart 3370 */
internal double _sin(x) double x ; {
    register double sum=0.0, x_square, mul ;
    register int i ;

    x /= PI2 ;
    x_square = x*x ;
    sum =x*(	0.1357884097877375669092680013e8+x_square*(
		-.4942908100902844161158627070e7+x_square*(
		0.4401030535375266501944918132e6+x_square*(
		-.138472724998245287305445709e5+x_square*
		0.1459688406665768722226959e3))));
    sum /=	0.8644558652922534429915149436e7+x_square*(
		0.4081792252343299749395778676e6+x_square*(
		0.9463096101538208180571257e4+x_square*(
		0.1326534908786136358911494e3+x_square)));
return( sum );
}

double sin( x ) double x ; {
    register int neg = FALSE ;
    register double val ;
    double fmod(), _sin();

    if ( x < 0. ) {
	x = -x ;
	neg = TRUE ;
    }
    x = fmod( x, TWO_PI );
    if ( x > PI ) {
	x -= PI ;
	neg = ! neg ;
    }
    if ( x > PI2 )
    	x = PI-x ;
    val = _sin( x );
    if ( neg )
    	val = -val ;
return( val );
}

double cos( x ) double x ; {
    register int neg = FALSE ;
    register double val ;
    double fmod(), _sin();

    if ( x < 0.)
	x = -x ;
    x = fmod( x, TWO_PI );
    if ( x > PI ) {
	x -= PI ;
	neg = ! neg ;
    }
    if ( x > PI2 ) {
	x = PI-x ;
	neg = ! neg ;
    }
    val = _sin( PI2-x );
    if ( neg )
    	val = -val ;
return( val );
}

double cotan(x)
register double x;
{
    register double y, tansub();
	
    y = fabs(x);
    if (y < 1.0/HUGE_VAL) {
	errno = ERANGE;
	if (x < 0.0)
	    return(-HUGE_VAL);
	else
	    return(HUGE_VAL);
    }
    return(tansub(x,y,2));
}

double tan(x) register double x;
{
    double tansub();
    return(tansub(x, fabs(x), 0));
}

#define P1 -0.13338350006421960681e+0
#define P2 +0.34248878235890589960e-2
#define P3 -0.17861707342254426711e-4
#define Q0 1.0
#define Q1 -0.46671683339755294240e+0
#define Q2 0.25663832289440112864e-1
#define Q3 -0.31181531907010027307e-3
#define Q4 0.49819433993786512270e-6

#define P(f,g) (((P3 * g P2) * g P1)* g * f + f)
#define Q(g) ((((Q4*g Q3)*g + Q2)*g Q1)*g + Q0)

#define YMAX 6.74652e09

static double tansub(x, y, flag)
register double x,y;
register int flag;
{
    register double f, g, modf();
    register double xnum, xden, xtemp;
    double xn;
	
    if (y > YMAX) {
	errno = ERANGE;
	return(0.0);
    }
    if (modf(x*0.63661977236758134308, &xn) >= 0.5)
	xn += (x < 0.0) ? -1.0 : 1.0;
    f = (x - xn*1.57080078125) + xn*4.454455103380768678308e-6;
    if ((fabs(f)) < 2.33e-10) {
	xnum = f;
	xden = 1.0;
    } else {
	g = f*f;
	xnum = P(f,g);
	xden =  Q(g);
    }
    flag |= ((int)xn & 1);
    switch (flag) {
	case 1:		/* A: tan, xn odd */
	    xnum = -xnum;
	case 2:		/* B: cotan, xn even */
	    return(xden/xnum);
		
	case 3:		/* C: cotan, xn odd */
	    xnum = -xnum;
	case 0:		/* D: tan, xn even */
	    return(xnum/xden);
    }
    return(0.0);
}

#define MAXEXP	1023
#define MINEXP	-1022

#define PI2	1.57079632679489661923

double atan2(v,u)
register double u,v;
{
    register double f,zero=0.0, frexp(), atan();
    int vexp, uexp;

    if (u == zero) {
	if (v == zero) {
	    errno = EDOM;
	    return(zero);
	}
	return(PI2);
    }

    frexp(v, &vexp);
    frexp(u, &uexp);
    if (vexp-uexp > MAXEXP-3)	/* overflow */
	f = PI2;
    else {
	if (vexp-uexp < MINEXP+3)	/* underflow */
	    f = zero;
	else
	    f = atan(fabs(v/u));
	if (u < zero)
	    f = PI - f;
    }
    if (v < zero)
	f = -f;
    return(f);
}

#define P0 -0.13688768894191926929e+2
#define P1 -0.20505855195861651981e+2
#define P2 -0.84946240351320683534e+1
#define P3 -0.83758299368150059274e+0
#define Q0 +0.41066306682575781263e+2
#define Q1 +0.86157349597130242515e+2
#define Q2 +0.59578436142597344465e+2
#define Q3 +0.15024001160028576121e+2

#define P(g) (((P3*g P2)*g P1)*g P0)
#define Q(g) ((((g Q3)*g Q2)*g Q1)*g Q0)

double atan(x)
register double x;
{
    register double f, r, g;
    register int n;
    static double Avals[4] = {
	0.0,
	0.52359877559829887308,
	1.57079632679489661923,
	1.04719755119659774615
    };
	
    n = 0;
    f = fabs(x);
    if (f > 1.0) {
	f = 1.0/f;
	n = 2;
    }
    if (f > 0.26794919243112270647) {
	f = (((0.73205080756887729353*f - 0.5) - 0.5) + f) /
	    (1.73205080756887729353 + f);
	++n;
    }
    if (fabs(f) < 2.3e-10)
	r = f;
    else {
	g = f*f;
	r = f + f *
	    ((P(g)*g)
	    /Q(g));
    }
    if (n > 1)
	r = -r;
    r += Avals[n];
    if (x < 0.0)
	r = -r;
    return(r);
}

double asin( x ) double x ; {
    register int neg = x<0.0 ;
    double sqrt(), atan();
    /* I use the identity that asin(x)=atan(1/sqrt(1/x^2-1)) */

    x *= x ;
    if ( x == 0.0 )
return( 0.0 );			/* arc sin(0)=0 */
    if ( x == 1.0 )
return( neg? -PI2 : PI2 );
    if ( x > 1.0 ) {
	errno = EDOM ;
return( 0.0 );
    }

    x = atan( 1.0/sqrt( 1.0/x - 1.0 ));
    if ( neg )
	x = -x ;
return( x );
}

double acos( x ) double x ; {
    register int neg = x<0.0 ;
    double sqrt(), atan();
    /* I use the identity that acos(x)=atan(sqrt(1/x^2-1)) */

    x *= x ;
    if ( x == 0.0 )
return( PI2 );			/* arc cos(0)=PI/2 */
    if ( x == 1.0 )
return( neg? PI : 0 );
    if ( x > 1.0 ) {
	errno = EDOM ;
return( 0.0 );
    }

    x = atan( sqrt( 1.0/x - 1.0 ));
    if ( neg )
	x = PI-x ;
return( x );
}

double hypot( x,y ) double x,y ; {
    /* returns the distance between (x,y) and the origin, goes to some effort
	to avoid overflow, calls sqrt()
    */
    register DOUBLE *xpt = ((DOUBLE *) &x), *ypt = ((DOUBLE *) &y);
    double sqrt(), sval ;
    int e ;

    e = (( xpt->dbl_exp > ypt->dbl_exp )? xpt->dbl_exp : ypt->dbl_exp)-EXPBASE;
    xpt->dbl_exp -= e ; ypt->dbl_exp -= e ;
    sval = sqrt( x*x+y*y );
    xpt = ((DOUBLE *) &sval);
    xpt->dbl_exp += e ;
return( sval );
}

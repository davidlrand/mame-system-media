#include <errno.h>
#define internal static
#define and	&&
#define or	||
#define not	!
#define FALSE	0
#define TRUE	1

#define PI	3.14159265358979323846
#define TWO_PI	6.28318530717958647693
#define TWO_OVER_PI	.63661977236758134307553505 /* 3490 */
#define PI4	0.78539816339744830961566084 /* 5819 */
#define PI2	1.57079632679489661923
#define E	2.71828182845904523536
#define LOG10	2.30258509299404568402
#define LOG2	0.69314718055994530942
#define LOGS2PI	0.91893853320467274178

#define MUL	1.1283791670955126	/* 2/sqrt(PI), for erf */
#define MAXE 21.00   /* for x>MAXE exp(x)+exp(-x) == exp(x) */

#define EXPBASE	1023
typedef struct {
    unsigned dbl_frac2 : 32 ;
    unsigned dbl_frac1 : 20 ;
    unsigned dbl_exp : 11 ;
    unsigned dbl_sign : 1 ;
} DOUBLE ;

extern int errno ;

int signgam = 0 ;

/* returns the logarithem of the absolute value of the gamma function, the
	sign is returned in the external variable signgam, which is 1/-1
	(or maybe 0 on an error)
*/
double gamma( x ) double x ; {
    double negamma(), posgamma(), largamma();

    signgam = 1 ;
    if ( x <= 0. )
return( negamma( x ));
    else if ( x < 8. )
return( posgamma( x ));
    else
return( largamma( x ));
}

static double negamma( x ) double x ; {
    double log(), sin(), floor(), gamma();
    double temp ;
    /* this is an identity
    	gamma( z ) = PI/( sin(PI*z) * (-z) * gamma( -z ) )
	I use it for negative values (I throw in some logs of course)
    */

    temp = -sin( PI*x )*x ;
    if ( temp == 0. or x == floor( x )) {
	errno = EDOM ;
return( 0. );
    }
    if ( temp < 0. ) {
	signgam = -1 ;
	temp = -temp ;
    }
return( log( PI/temp )- gamma( -x ) );
}

static double largamma( x ) double x ; {
    /* Stirling's formula, coeficients from Hart 5404 */
    static double p[]= {
	.833333333333331018375e-1,
	-.277777777735865004e-2,
	.793650576493454e-3,
	-.5951896861197e-3,
	.83645878922e-3,
	-.1633436431e-2
    };
    double log();
    double sum, xsq ;
    register int i ;

    xsq = 1./(x*x) ;
    sum = p[5];
    for ( i=4 ; i >= 0 ; i-- )
	sum = xsq*sum + p[i];
return( (x-.5)*log( x ) - x +LOGS2PI+sum/x );
}

static double posgamma( x ) double x ; {
    /* coeficients from Hart #5243 */
    double log();
    double prod = 1.; 
    double psum, qsum ;
    register int i ;
    static double p[] = {
	-.423536895097440896471976416e5,
	-.208868617892698873643119676e5,
	-.87627102978521489560976106e4,
	-.20085274013072791214669443e4,
	-.4393304440600256761394109e3,
	-.501086937529709530159044e2,
	-.67449507245925289918083e1
    };
    static double q[]= {
	-.423536895097440900102391757e5,
	-.29803853309256649932413027e4,
	.99403074150827709015210114e4,
	-.1528607273779522024828658e4,
	-.4990285266214390483429395e3,
	.1894982341570280164182074e3,
	-.230815515245801245621624e2,
	1.
    };

    if ( x == 1. or x == 2. )
return( 0. );
    while ( x >= 3. ) {
	x-- ;
	prod *= x ;
    }
    while ( x < 2. ) {
	prod /= x ;
	x++ ;
    }
    x -= 2. ;
    psum = 0. ; qsum = q[7];
    for ( i=6 ; i >= 0 ; i-- ) {
	psum = x*psum + p[i];
	qsum = x*qsum + q[i];
    }
return( log( prod*psum/qsum ));
}

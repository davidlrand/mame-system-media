#include <errno.h>
#define internal static
#define and	&&
#define or	||
#define not	!
#define FALSE	0
#define TRUE	1

#define PI	3.14159265358979323846
#define TWO_PI	6.28318530717958647693
#define TWO_OVER_PI	.63661977236758134307553505 /* 3490 */
#define PI4	0.78539816339744830961566084 /* 5819 */
#define PI2	1.57079632679489661923
#define E	2.71828182845904523536
#define LOG10	2.30258509299404568402
#define LOG2	0.69314718055994530942
#define LOGS2PI	0.91893853320467274178

#define MUL	1.1283791670955126	/* 2/sqrt(PI), for erf */
#define MAXE 21.00   /* for x>MAXE exp(x)+exp(-x) == exp(x) */

#define EXPBASE	1023
typedef struct {
    unsigned dbl_frac2 : 32 ;
    unsigned dbl_frac1 : 20 ;
    unsigned dbl_exp : 11 ;
    unsigned dbl_sign : 1 ;
} DOUBLE ;

extern int errno ;

/* the following routines are included:
	jn(n,x)		;nth bessel function at x
	j0(x)		;0th bessel function at x
	j1(x)		;1st bessel function at x
	yn(n,x)		;nth bessel function of second kind at x
	y0(x)		;0th bessel function of second kind at x
	y1(x)		;1st bessel function of second kind at x
	erf(x)		;error function at x
	erfc(x)		;complimentary error function at x
	exp(x)		;e^x
	log(x)		;natural log of x
	log10(x)	;log base 10 of x
	sqrt(x)		;square root of x
	pow(x,y)	;x^y
	sinh(x)		;hyperbolic sine of x
	cosh(x)		;hyperbolic cosine of x
	tanh(x)		;hyperbolic tangent of x
	sin(x)		;sine of x
	cos(x)		;cosine of x
	tan(x)		;tangent of x
	asin(x)		;arc sine of x
	acos(x)		;arc cosine of x
	atan(x)		;arc tangent of x
	atan2(y,x)	;arc tangent of y/x with overflow protection,
			; and checks to see that the result is -PI to PI
	gamma(x)	;Returns the log of the absolute value of the
			; gamma function, the sign is in extern int signgam ;
	floor(x)	;Returns the largest integer not larger than x
	ceil(x)		;Returns the smallest integer not smaller than x
	fmod(x,y)	;Returns the x-floor(x/y)*y
	abs(x)		;Returns absolute value of x (int)
	fabs(x)		;Returns absolute value of x (double)
	hypot(x,y)	;Returns distance between (x,y) and (0,0), avoids
			; overflow ---COMMENTED OUT 3/30/85-----TM------
(there is also a random number generater in crtlib.c that returns an int)
*/
/* the following are included for internal use:
	frexp(x,&exp)	;Returns fraction part of x, sets exp to exponant
	faddexp(x,exp)	;Adds exp to the exponant of x, checks for overflow
*/
/* I do not have the following routine defined in the SYSTEM 5 manual as
 part of the math package.
	matherr(x)	;defines error behavior
*/
/* the error returns are not the same as those in the manual.  I did try to
set errno when appropriate.
*/

/* all constants/coeficients from Computer Approximations by Hart et al. */
/*  for small x (<8) j0 is evaluated by JZER0 5849
	for large x (>8) j0 is evaluated by PZERO 6549 and QZERO 6949
*/
/*  for small x (<8) y0 is evaluated by YZER0 6049
	for large x (>8) y0 is evaluated by PZERO 6549 and QZERO 6949
*/

static asym0( x, p0, q0 ) double x, *p0, *q0 ; {
    static double pp[]= { .5393485083869438325262122897e7,
	.1233238476817638145232406055e8,
	.8413041456550439208464315611e7,
	.2016135283049983642487182349e7,
	.1539826532623911470917825993e6,
	.2485271928957404011288128951e4 };
    static double pq[]= { .5393485083869438325560444960e7,
	.1233831022786324960844856182e8,
	.8426449050629797331554404810e7,
	.2025066801570134013891035236e7,
	.1560017276940030940592769933e6,
	.2615700736920839685159081813e4,
	1. };
    static double qp[]= { -.3984617357595222463506790588e4,
	-.1038141698748464093880530341e5,
	-.8239066313485606568803548860e4,
	-.2365956170779108192723612816e4,
	-.2262630641933704113967255053e3,
	-.4887199395841261531199129300e1 };
    static double qq[]= { .2550155108860942382983170882e6,
	.6667454239319826986004038103e6,
	.5332913634216897168722255057e6,
	.1560213206679291652539287109e6,
	.1570489191515395519392882766e5,
	.4087714673983499223402830260e3,
	1. };
    double ppsum, pqsum, qpsum, qqsum, xsq ;
    register int i;

    x = 8./x ;
    xsq = x*x ;

    pqsum = pq[6]; qqsum = qq[6];
    ppsum = qpsum = 0.0 ;
    for ( i=5 ; i >= 0 ; i-- ) {
	pqsum = xsq*pqsum + pq[i];
	ppsum = xsq*ppsum + pp[i];
	qqsum = xsq*qqsum + qq[i];
	qpsum = xsq*qpsum + qp[i];
    }
    *p0 = ppsum / pqsum ; *q0 = x * (qpsum/qqsum) ;
}

double j0( x ) double x ; {
    static double p[]= { .4933787251794133561816813446e21,
	-.11791576291076105360384408e21,
	.6382059341072356562289432465e19,
	-.1367620353088171386865416609e18,
	.1434354939140344111664316553e16,
	-.8085222034853793871199468171e13,
	.2507158285536881945555156435e11,
	-.4050412371833132706360663322e8,
	.2685786856980014981415848441e5 };
    static double q[]= { .4933787251794133562113278438e21,
	.5428918384092285160200195092e19,
	.3024635616709462698627330784e17,
	.1127756739679798507056031594e15,
	.3123043114941213172572469442e12,
	.6699987672982239671814028660e9,
	.1114636098462985378182402543e7,
	.1363063652328970604442810507e4,
	.1e1 };
    double sin(), cos(), sqrt();
    double psum, qsum ;
    register int i;

    if ( x < 0. )
	x = -x ;
    if ( x < 8.0 ) {
	x *= x ;
	psum = p[8]; qsum=q[8];
	for ( i=7 ; i>=0 ; i-- ) {
	    psum = x*psum+p[i];
	    qsum = x*qsum+q[i];
	}
return( psum/qsum );
    } else {
	asym0( x, &psum, &qsum );
return( sqrt( TWO_OVER_PI/x )*(psum*cos(x-PI4)-qsum*sin(x-PI4 )) );
    }
}

double y0( x ) double x ; {
    static double p[]= { -.9271040364331778065997077567e23,
	 .2221795171464734959461033921e24,
	-.1797501535351026323743332233e23,
	 .4867235042898163780309467558e21,
	-.6166463755967882455848436005e19,
	 .4198535264896044127221217976e17,
	-.1630388704719033222414474226e15,
	 .3626112371023781263507858047e12,
	-.4322070111754509283576952951e9,
	 .2157005807808836412437323737e6 };
    static double q[]= { .1256165423798014008016381865e25,
	.1250632231601396786528969274e23,
	.6301243461119941981938406355e20,
	.2127990247831028575645069270e18,
	.5365328846624175107302324905e15,
	.1060973970586885270806820407e13,
	.1672209200208482972518502400e10,
	.2068779667854516822965618638e7,
	.1877893230795989427041920381e4,
	1. };
    double sin(), cos(), sqrt(), log(), j0();
    double psum, qsum, xsq ;
    register int i;

    if ( x <= 0. ) {
	errno = EDOM ;
return( 0.0 );
    }
    if ( x < 8.0 ) {
	xsq = x*x ;
	psum = p[9]; qsum=q[9];
	for ( i=8 ; i>=0 ; i-- ) {
	    psum = xsq*psum+p[i];
	    qsum = xsq*qsum+q[i];
	}
return( psum/qsum+TWO_OVER_PI*j0(x)*log(x) );
    } else {
	asym0( x, &psum, &qsum );
return( sqrt( TWO_OVER_PI/x )*(psum*sin(x-PI4)+qsum*cos(x-PI4 )) );
    }
}

/* all constants/coeficients from Computer Approximations by Hart et al. */
/*  for small x (<8) j0 is evaluated by JONE 6050
	for large x (>8) j0 is evaluated by PONE 6750 and QONE 7150
*/
/*  for small x (<8) y0 is evaluated by YONE 6447
	for large x (>8) y0 is evaluated by PONE 6750 and QONE 7150
*/

static asym1( x, p1, q1 ) double x, *p1, *q1 ; {
    static double pp[]= {
	-.4435757816794127857114720794e7,
	-.9942246505077641195658377899e7,
	-.6603373248364939109255245434e7,
	-.1523529351181137383255105722e7,
	-.1098240554345934672737413139e6,
	-.1611616644324610116477412898e4
    };
    static double pq[]= { 
	-.4435757816794127856828016962e7,
	-.9934124389934585658967556309e7,
	-.6585339479723087072826915069e7,
	-.1511809506634160881644546358e7,
	-.1072638599110382011903063867e6,
	-.1455009440190496182453565068e4,
	1.
    };
    static double qp[]= {
	.3322091340985722351859704442e5,
	.8514516067533570196555001171e5,
	.6617883658127083517939992166e5,
	.1849426287322386679652009819e5,
	.1706375429020768002061283546e4,
	.3526513384663603218592175580e2
    };
    static double qq[]= { 
	.7087128194102874357375502472e6,
	.1819458042243997298924553839e7,
	.1419460669603720892855755253e7,
	.4002944358226697511708610813e6,
	.3789022974577220264142952256e5,
	.8638367769604990967475517183e3,
	1.
    };
    double ppsum, pqsum, qpsum, qqsum, xsq ;
    register int i;

    x = 8./x ;
    xsq = x*x ;

    pqsum = pq[6]; qqsum = qq[6];
    ppsum = qpsum = 0.0 ;
    for ( i=5 ; i >= 0 ; i-- ) {
	pqsum = xsq*pqsum + pq[i];
	ppsum = xsq*ppsum + pp[i];
	qqsum = xsq*qqsum + qq[i];
	qpsum = xsq*qpsum + qp[i];
    }
    *p1 = ppsum / pqsum ; *q1 = x * (qpsum/qqsum) ;
}

double j1( x ) double x ; {
    static double p[]= { 
	.5811993540016061439280508090e21,
	-.6672106568924916298020941484e20,
	.2316433580634002297931815435e19,
	-.3588817569910106050743641413e17,
	.2908795263834775409737601689e15,
	-.1322983480332126453125473247e13,
	.3413234182301700539091292655e10,
	-.4695753530642995859767162166e7,
	.2701122710892323414856790990e4
    };
    static double q[]= {
	0.1162398708003212287858529400e22,
	0.1185770712190320999837113348e20,
	0.6092061398917521746105196863e17,
	0.2081661221307607351240184229e15,
	0.5243710262167649715406728642e12,
	0.1013863514358673989967045588e10,
	0.1501793594998585505921097578e7,
	0.1606931573481487801970916749e4,
	1.
    };
    double sin(), cos(), sqrt();
    double psum, qsum, xsq ;
    register int i;

    if ( x < 0. )
	x = -x ;
    if ( x < 8.0 ) {
	xsq = x*x ;
	psum = p[8]; qsum=q[8];
	for ( i=7 ; i>=0 ; i-- ) {
	    psum = xsq*psum+p[i];
	    qsum = xsq*qsum+q[i];
	}
return( x*psum/qsum );
    } else {
	asym1( x, &psum, &qsum );
return( sqrt( TWO_OVER_PI/x )*(psum*cos(x-3*PI4)-qsum*sin(x-3*PI4 )) );
    }
}

double y1( x ) double x ; {
    static double p[]= {
	-.9963753424306922225996744354e23,
	0.2655473831434854326894248968e23,
	-.1212297555414509577913561535e22,
	0.2193107339917797592111427556e20,
	-.1965887462722140658820322248e18,
	0.9569930239921683481121552788e15,
	-.2580681702194450950541426399e13,
	0.3639488548124002058278999428e10,
	-.2108847540133123652824139923e7
    };
    static double q[]= {
	0.5082067366941243245314424152e24,
	0.5435310377188854170800653097e22,
	0.2954987935897148674290758119e20,
	0.1082258259408819552553850180e18,
	0.2976632125647276729292742282e15,
	0.6465340881265275571961681500e12,
	0.1128686837169442121732366891e10,
	0.1563282754899580604737366452e7,
	0.1612361029677000859332072312e4,
	1.
    };
    double sin(), cos(), sqrt(), log(), j1();
    double psum, qsum, xsq ;
    register int i;

    if ( x <= 0. ) {
	errno = EDOM ;
return( 0.0 );
    }
    if ( x < 8.0 ) {
	xsq = x*x ;
	psum = 0.0; qsum=q[9];
	for ( i=8 ; i>=0 ; i-- ) {
	    psum = xsq*psum+p[i];
	    qsum = xsq*qsum+q[i];
	}
return( x*psum/qsum+TWO_OVER_PI*(j1(x)*log(x)-1./x) );
    } else {
	asym1( x, &psum, &qsum );
return( sqrt( TWO_OVER_PI/x )*(psum*sin(x-3.*PI4)+qsum*cos(x-3.*PI4 )) );
    }
}

/* compute jn & yn nth bessel functions of 1st and 2nd kind */
/* for jn:
	first range reduce things so that everything is non-negative
	check for the special cases of 
		n==0 => call j0
		n==1 => call j1
		x==0.=> return 0. (unless n==0 => return 1. )
	then for x<n use the obvious power series
		jn(x)= sum( ( (-1)^k * (x/2)^(k+n) ) / ( k! * (n+k)! ) )
	and for x>=n use the recurance
		j(n+1)(x) = 2nJn(x)/x - J(n-1)(x)
*/
/* for yn:
	range reduce, and check that x is positive
	then check for special cases n=0,1 and call y0,y1
	always use the recurance, there is no nice power series
*/

static double __jn( n, x ) int n ; double x ; {
    register double sum, fact ;
    register int i ;

    x /= 2.0 ;
    for ( i=1, fact=1.0 ; i<=n ; i++ ) fact = (fact*x)/i ;
    sum = fact ;
    x *= x ;
    for ( i=1 ; sum+fact != sum ; i++ ) {
	fact *= -x/(i*(i+n)) ;
	sum += fact ;
    }
return( sum );
}

double jn(n,x) int n ; double x ; {
    int neg = 0, i ;
    double val, val1, temp ;
    double j0(), j1();

    if ( n < 0 ) {
	n = -n ;
	if ( n%2 == 1 )
	    neg = 1 ;
    }
    if ( x < 0. ) {
	x = -x ;
	if ( n%2 == 1 )
	    neg = ! neg ;
    }
    if ( n == 0 )
	val = j0( x );
    else if ( n == 1 )
	val = j1( x );
    else if ( x == 0.0 )
return( 0.0 );
    else if ( x < n )
	val = __jn( n, x );
    else {
	val1 = j0(x);
	val = j1(x);
	for ( i=1 ; i < n ; i++ ) {
	    temp = (2.*i)*val/x-val1 ;
	    val1 = val ;
	    val = temp;
	}
    }
    if ( neg )
	val = -val ;
return( val );
}

double yn(n,x) int n ; double x ; {
    int neg = 0, i ;
    double val, val1, temp ;
    double y0(), y1();

    if ( n < 0 ) {
	n = -n ;
	if ( n%2 == 1 )
	    neg = 1 ;
    }
    if ( x <= 0. ) {
	errno = EDOM ;
return( 0.0 );
    }
    if ( n == 0 )
	val = y0( x );
    else if ( n == 1 )
	val = y1( x );
    else {
	val1 = y0(x);
	val = y1(x);
	for ( i=1 ; i < n ; i++ ) {
	    temp = (2.*i)*val/x-val1 ;
	    val1 = val ;
	    val = temp;
	}
    }
    if ( neg )
	val = -val ;
return( val );
}

double erf(x) double x ; {
    double sum, fact, erfc();
    register int i, sign=1 ;
    /* for x in (-.5,.5) I use the tayor series, for larger x 1-erfc() */

    if ( x < 0. ) {
	x = -x ;
	sign = -1 ;
    }

#ifdef vaxd_float	/* erfc < 1e-38 here */
    if ( x > 10. )
return( (double) sign );
#endif
    if ( x > .5 )
return( 1.-erfc( x ));

    fact = sum = x ;
    x *= x ;
    for ( i= 1 ; sum+fact != sum ; i++ ) {
	fact *= -x/i ;
	sum += fact/(2*i+1) ;
    }
return( sign*MUL*sum );
}

double erfc( x ) double x ; {
    double exp(), erf();
    /* coeficients are from Hart 5667 */
    static double p[]= {
	.18263348842295112592168999e4,
	.28980293292167655611275846e4,
	.2320439590251635247384768711e4,
	.1143262070703886173606073388e4,
	.3685196154710010637133875746e3,
	.7708161730368428609781633646e2,
	.9675807882987265400604202961e1,
	.5641877825507397413087057563
    };
    static double q[]= {
	.18263348842295112595576438e4,
	.495882756472114071495438422e4,
	.60895424232724435504633068e4,
	.4429612803883682726711528526e4,
	.2094384367789539593790281779e4,
	.6617361207107653469211984771e3,
	.1371255960500622202878443578e3,
	.1714980943627607849376131193e2,
	1.
    };
    double psum, qsum ;
    register int i;

    if ( x < 0. )
return( 2.-erfc( -x ));
#ifdef vaxd_float
    if ( x > 10. )
return( 0. );
#endif
    psum = 0. ; qsum = q[8];
    for ( i=7 ; i>=0 ; i-- ) {
	psum = x*psum +p[i];
	qsum = x*qsum +q[i];
    }
return( exp( -x*x )*psum/qsum );
}

#include <errno.h>
#define internal static
#define and	&&
#define or	||
#define not	!
#define FALSE	0
#define TRUE	1

#define PI	3.14159265358979323846
#define TWO_PI	6.28318530717958647693
#define TWO_OVER_PI	.63661977236758134307553505 /* 3490 */
#define PI4	0.78539816339744830961566084 /* 5819 */
#define PI2	1.57079632679489661923
#define E	2.71828182845904523536
#define LOG10	2.30258509299404568402
#define LOG2	0.69314718055994530942
#define LOGS2PI	0.91893853320467274178

#define MUL	1.1283791670955126	/* 2/sqrt(PI), for erf */
#define MAXE 21.00   /* for x>MAXE exp(x)+exp(-x) == exp(x) */

#define EXPBASE	1023
typedef struct {
    unsigned dbl_frac2 : 32 ;
    unsigned dbl_frac1 : 20 ;
    unsigned dbl_exp : 11 ;
    unsigned dbl_sign : 1 ;
} DOUBLE ;

extern int errno ;

double floor( d ) double d ; {
    register DOUBLE *pt = (DOUBLE *) &d ;
    register int i, bit, exp ;
    double ceil();
    /* returns the greatest int not more than d */

    if ( d < 0 )
return( -ceil( -d ));
    else if (( exp = pt->dbl_exp - 1023 )< 0 )
return( 0.0 );
    else if ( exp >= 20+32 )
return( d );

    if ( exp <= 20 ) {
	pt->dbl_frac1 &= ~(0xfffff>>exp);
	pt->dbl_frac2 = 0 ;
    } else {
	pt->dbl_frac2 &= ~(0x7fffffff>>(exp-21));
    }
return( d );
}

double ceil( d ) double d ; {
    register DOUBLE *pt = (DOUBLE *) &d ;
    register int i, bit, exp ;
    double floor();
    /* returns the smallest int not less than d */
    /* note that I assume all shifts are arithmetric, the sign bit is copied*/
    /* this fails if exp > 53, who cares? */

    exp = ((DOUBLE *) &d)->dbl_exp - EXPBASE ;
    if ( d < 0 )
return( -floor( -d ));
    else if ( exp >= 23+32 )
return( d );
    else if ( exp == -EXPBASE )
return( 0.0 );
    else if ( exp < 0 )
return( 1.0 );

    i = 0 ;
    if ( exp <= 20 ) {
	for ( bit = 1<<(20-exp) ; ! i && bit != 0 ; bit >>= 1 )
	    if ( pt->dbl_frac1 & bit ) i=1 ;
	exp = 20 ;
    }
    for ( bit = 1<<(52-exp) ; ! i && bit != 0 ; bit >>= 1 )
	if ( pt->dbl_frac2 & bit ) i=1 ;
    d = floor( d );
    if ( i )
	d++ ;

return( d );
}

double frexp( x, exp ) double x ; int *exp ; {
    /* returns a number between (in absolute value) .5 and 1, and an exponant
	such that x = frexp( x,&exp )* (2^exp)
    */
    register DOUBLE *pt = ((DOUBLE *) &x);

    *exp = pt->dbl_exp-1023 ; pt->dbl_exp = 1023 ;
return( x );
}

double faddexp( x, exp ) double x ; int exp ; {
    register DOUBLE *pt = ((DOUBLE *) &x);
    register int e = pt->dbl_exp+exp ;

    if ( e >= 2048 ) {
	errno = ERANGE ;
return( 0.0 );
    } else if ( e <= 0 )
return( 0. );
    pt->dbl_exp = e ;
return( x );
}
/* end of ieee floating point standard routines */

double fmod(x,y) double x,y ; {
    register int neg = (x<0.0);

    if ( y == 0.0 )
return( x );
    else if ( y < 0.0 )
	y = -y ;
    if ( x < 0.0 )
	x = -x ;
    if (( x -= y*floor( x/y ) )== 0.0 )
return( 0.0 );

    if ( neg )
return( x-y );

return( x );
}

double fabs( x ) double x ; {
    if ( x >= 0.0 )
return( x );

return( -x );
}

int abs( x ) int x ; {
    if ( x >= 0 )
return( x );

return( -x );
}

/* Virtual Screen I/O calls */

#include <stdio.h>

#define MONO_CARD (UBYTE *)0x0b0000L
#define COLOR_CARD (UBYTE *)0x0b8000L
#define DEF_ATTRIB 0x07

struct _vsstr {
    WORD montype;
    WORD monsize;
    WORD maxR, maxC;
    UBYTE attrib;
    UBYTE *locscreen;
    UBYTE *remscreen;
};

struct pix320 {
    unsigned pix3 : 2;
    unsigned pix2 : 2;
    unsigned pix1 : 2;
    unsigned pix0 : 2;
};

struct pix640 {
    unsigned pix7 : 1;
    unsigned pix6 : 1;
    unsigned pix5 : 1;
    unsigned pix4 : 1;
    unsigned pix3 : 1;
    unsigned pix2 : 1;
    unsigned pix1 : 1;
    unsigned pix0 : 1;
};


typedef char	**ARG_PT ;
    
UBYTE *v_init(monitor)
WORD monitor;
{
    UBYTE *myalloc();
    struct _vsstr *vs;

    vs=(struct _vsstr *)myalloc(sizeof(struct _vsstr));
    
    vs->montype = monitor;
    vs->attrib = DEF_ATTRIB;
    
    switch(monitor) {
	
	case 0: /* 40x25 BW */
	case 1: /* 40x25 Color */
	    
	    vs->monsize = 40*25*2;
	    vs->remscreen = COLOR_CARD;
	    vs->maxR = 25;
	    vs->maxC = 40;
	    break;
	
	case 2: /* 80x25 BW */
	case 3: /* 80x25 Color */
	
	    vs->monsize = 80*25*2;
	    vs->remscreen = COLOR_CARD;
	    vs->maxR = 25;
	    vs->maxC = 80;
	    break;
	    
	case 4: /* 320x200 Color */
	case 5: /* 320x200 BW */
	    vs->monsize = 16 * 1024;
	    vs->remscreen = COLOR_CARD;
	    vs->maxR = 200;
	    vs->maxC = 320;
	    break;
	    
	case 6: /* 640x200 BW */
	
	    vs->monsize = 16 * 1024;
	    vs->remscreen = COLOR_CARD;
	    vs->maxR = 200;
	    vs->maxC = 640;
	    break;
	    
	case 10: /* 40x25 BW */
	    
	    vs->monsize = 40*25*2;
	    vs->remscreen = MONO_CARD;
	    vs->maxR = 25;
	    vs->maxC = 40;
	    break;
	
	case 12: /* 80x25 BW */
	
	    vs->monsize = 80*25*2;
	    vs->remscreen = MONO_CARD;
	    vs->maxR = 25;
	    vs->maxC = 80;
	    break;

	case 20: /* 40x24 BW */
	case 21: /* 40x24 Color */
	    
	    vs->monsize = 40*24*2;
	    vs->remscreen = COLOR_CARD;
	    vs->maxR = 24;
	    vs->maxC = 40;
	    break;
	
	case 22: /* 80x24 BW */
	case 23: /* 80x24 Color */
	
	    vs->monsize = 80*24*2;
	    vs->remscreen = COLOR_CARD;
	    vs->maxR = 24;
	    vs->maxC = 80;
	    break;
	    
	case 30: /* 40x24 BW */
	    
	    vs->monsize = 40*24*2;
	    vs->remscreen = MONO_CARD;
	    vs->maxR = 24;
	    vs->maxC = 40;
	    break;
	
	case 32: /* 80x24 BW */
	
	    vs->monsize = 80*24*2;
	    vs->remscreen = MONO_CARD;
	    vs->maxR = 24;
	    vs->maxC = 80;
	    break;
	
	default:
	    printf("\n Invalid parameter passed to v_init = %d",monitor);
	    exit(1);
    }
    
    vs->locscreen = myalloc(vs->monsize);
    
    v_cls(vs);
    return((UBYTE *)vs);
}

VOID v_free(vs)
register struct _vsstr *vs;
{
    free(vs->locscreen);
    free(vs);
}


	    
static UBYTE *myalloc(size)
int size;
{
    register UBYTE *t,*malloc();
    
    if ((t=malloc(size))==NULL) {
	printf("\nCan't allocate %d bytes of memory for virtual screen.",size);
	exit(1);
    }
    return(t);
}

UBYTE v_attrib(vs,att)
register struct _vsstr *vs;
UBYTE att;
{
    register UBYTE old;
    
    old = vs->attrib;
    vs->attrib = att;
    return(old);
}

VOID v_cls(vs)
register struct _vsstr *vs;
{
    register UBYTE *temp,*temp1;
    
    temp1=temp=vs->locscreen;

    switch (vs->montype) {
	case 4:
	case 5:
	case 6:
	    
	    *temp++ = 0;
	    *temp++ = 0;
	    *temp++ = 0;
	    *temp++ = 0;
	    break;
	    
	default:
	    *temp++ = ' ';
	    *temp++ = vs->attrib;
	    *temp++ = ' ';
	    *temp++ = vs->attrib;
	    break;
    }
    
    COPYD_(temp1, temp, (vs->monsize/4)-1);
}

    
VOID v_box(vs,ulr,ulc,lrr,lrc,color)
register struct _vsstr *vs;
ULONG ulr,ulc,lrr,lrc,color;
{
    register ULONG r,c,val;
    register UBYTE *t;
    register ULONG Coffset = vs->maxC * 2;
    register ULONG Roffset = vs->maxR * 2;
    register ULONG Temp, Temp1;
    
    UBYTE Attrib = vs->attrib;

    switch(vs->montype) {
	case 4:
	case 5:
	case 6:
	    v_line(vs,ulr,ulc,ulr,lrc,color);	/* Top line */
	    v_line(vs,ulr,ulc,lrr,ulc,color);	/* Left line */
	    v_line(vs,ulr,lrc,lrr,lrc,color);	/* Right line */
	    v_line(vs,lrr,ulc,lrr,lrc,color);	/* Bottom line */
return;
    }
    
    if (ulr<lrr && ulc<lrc && lrr<vs->maxR && lrc<vs->maxC) {
	
	Temp = (ULONG)vs->locscreen + ulc * 2;
	Temp1 = (ULONG)vs->locscreen + lrc * 2;
	
	for (r=ulr+1;r<lrr;r++) {
	    t = (UBYTE *) Temp + (r * Coffset);
	    
	    switch (*t) {
		case 179:
		case 195:
		case 180:
		case 197:
		    *++t = Attrib;
		    break; /* Already a vertical line here */
		
		case 193:
		case 194:
		case 196:
		    *t++ = 197; /* Horizontal/vertical intersection */
		    *t = Attrib;
		    break;
		    
		case 218:
		    *t++ = 195; /* Vertical/TL Corner intersection */
		    *t = Attrib;
		    break;
		
		case 191:
		    *t++ = 180; /* Vertical/TR Corner intersection */
		    *t = Attrib;
		    break;
		    
		case 192:
		    *t++ = 195; /* Vertical/BL Corner intersection */
		    *t = Attrib;
		    break;
		    
		case 217:
		    *t++ = 180; /* Vertical/BR Corner intersection */
		    *t = Attrib;
		    break;
		    
		default:
		    *t++ = 179; /* vertical line */
		    *t = Attrib;
		    break;
	    }
		    
	    t = (UBYTE *) Temp1 + (r * Coffset);
	    
	    switch (*t) {
		case 179:
		case 195:
		case 180:
		case 197:
		    *++t = Attrib;
		    break; /* Already a vertical line here */
		
		case 193:
		case 194:
		case 196:
		    *t++ = 197; /* Horizontal/vertical intersection */
		    *t = Attrib;
		    break;
		    
		case 218:
		    *t++ = 195; /* Vertical/TL Corner intersection */
		    *t = Attrib;
		    break;
		
		case 191:
		    *t++ = 180; /* Vertical/TR Corner intersection */
		    *t = Attrib;
		    break;
		    
		case 192:
		    *t++ = 195; /* Vertical/BL Corner intersection */
		    *t = Attrib;
		    break;
		    
		case 217:
		    *t++ = 180; /* Vertical/BR Corner intersection */
		    *t = Attrib;
		    break;
		    
		default:
		    *t++ = 179; /* vertical line */
		    *t = Attrib;
		    break;
	    }
	}
	
	Temp = (ULONG)vs->locscreen + (ulr * Coffset);
	Temp1 = (ULONG)vs->locscreen + (lrr * Coffset);
	
	for (c=ulc+1;c<lrc;c++) {
	    t = (UBYTE *)Temp + (c * 2);
	    switch (*t) {
		case 196:
		case 194:
		case 193:
		case 197:
		    *++t = Attrib;
		    break; /* Already a horizontal line here */
		
		case 195:
		case 180:
		case 179:
		    *t++ = 197; /* Horizontal/vertical intersection */
		    *t = Attrib;
		    break;
		    
		case 218:
		    *t++ = 194; /* Horizontal/TL Corner intersection */
		    *t = Attrib;
		    break;
		
		case 191:
		    *t++ = 194; /* Horizontal/TR Corner intersection */
		    *t = Attrib;
		    break;
		    
		case 192:
		    *t++ = 193; /* Horizontal/BL Corner intersection */
		    *t = Attrib;
		    break;
		    
		case 217:
		    *t++ = 193; /* Horizontal/BR Corner intersection */
		    *t = Attrib;
		    break;
		    
		default:
		    *t++ = 196; /* Horizontal line */
		    *t = Attrib;
		    break;
	    }

	    t = (UBYTE *)Temp1 + (c * 2);
	    switch (*t) {
		case 196:
		case 194:
		case 193:
		case 197:
		    *++t = Attrib;
		    break; /* Already a horizontal line here */
		
		case 195:
		case 180:
		case 179:
		    *t++ = 197; /* Horizontal/vertical intersection */
		    *t = Attrib;
		    break;
		    
		case 218:
		    *t++ = 194; /* Horizontal/TL Corner intersection */
		    *t = Attrib;
		    break;
		
		case 191:
		    *t++ = 194; /* Horizontal/TR Corner intersection */
		    *t = Attrib;
		    break;
		    
		case 192:
		    *t++ = 193; /* Horizontal/BL Corner intersection */
		    *t = Attrib;
		    break;
		    
		case 217:
		    *t++ = 193; /* Horizontal/BR Corner intersection */
		    *t = Attrib;
		    break;
		    
		default:
		    *t++ = 196; /* Horizontal line */
		    *t = Attrib;
		    break;
	    }
	}
	
	t = vs->locscreen + (ulr * Coffset) + (ulc * 2);
	switch (*t) {
	    case 218:
	    case 194:
	    case 195:
	    case 197:
		    *++t = Attrib;
		break; /* Already a corner here */
		
	    case 191:
	    case 196:
		*t++ = 194; /* Horizontal/Corner intersection */
		*t = Attrib;
		break;
		    
	    case 192:
	    case 179:
		*t++ = 195; /* Vertical/Corner intersection */
		*t = Attrib;
		break;
		
	    case 180:
	    case 193:
	    case 217:
		*t++ = 197; /* Vertical/Horizontal intersection */
		*t = Attrib;
		break;
		    
	    default:
		*t++ = 218; /* Upper left corner */
		*t = Attrib;
		break;
	}
	t = vs->locscreen + (ulr * Coffset) + (lrc * 2);
	switch (*t) {
	    case 191:
	    case 194:
	    case 197:
	    case 180:
		    *++t = Attrib;
		break; /* Already a corner here */
		
	    case 196:
	    case 218:
		*t++ = 194; /* Horizontal/Corner intersection */
		*t = Attrib;
		break;
		    
	    case 179:
	    case 217:
		*t++ = 180; /* Vertical/Corner intersection */
		*t = Attrib;
		break;
		
	    case 192:
	    case 193:
	    case 195:
		*t++ = 197; /* Vertical/Horizontal intersection */
		*t = Attrib;
		break;
		    
	    default:
		*t++ = 191; /* Upper right corner */
		*t = Attrib;
		break;
	}
	t = vs->locscreen + (lrr * Coffset) + (ulc * 2);
	switch (*t) {
	    case 192:
	    case 193:
	    case 195:
	    case 197:
		    *++t = Attrib;
		break; /* Already a corner here */
		
	    case 179:
	    case 218:
		*t++ = 195; /* Horizontal/Corner intersection */
		*t = Attrib;
		break;
		    
	    case 196:
	    case 217:
		*t++ = 193; /* Vertical/Corner intersection */
		*t = Attrib;
		break;
		
	    case 180:
	    case 191:
	    case 194:
		*t++ = 197; /* Vertical/Horizontal intersection */
		*t = Attrib;
		break;
		    
	    default:
		*t++ = 192; /* Lower left corner */
		*t = Attrib;
		break;
	}
	t = vs->locscreen + (lrr * Coffset) + (lrc * 2);
	switch (*t) {
	    case 217:
	    case 180:
	    case 193:
	    case 197:
		    *++t = Attrib;
		break; /* Already a corner here */
		
	    case 196:
	    case 192:
		*t++ = 193; /* Horizontal/Corner intersection */
		*t = Attrib;
		break;
		    
	    case 179:
	    case 191:
		*t++ = 180; /* Vertical/Corner intersection */
		*t = Attrib;
		break;
		
	    case 218:
	    case 194:
	    case 195:
		*t++ = 197; /* Vertical/Horizontal intersection */
		*t = Attrib;
		break;
		    
	    default:
		*t++ = 217; /* Lower right corner */
		*t = Attrib;
		break;
	}
	
	switch(vs->montype) {
	    
	    case 0:
	    case 1:
	    case 2:
	    case 3:
	    case 20:
	    case 21:
	    case 22:
	    case 23:
		/* If on a color card, flood with color */
		for (r = ulr + 1 ; r < lrr ; r++) {
		    Temp = (ULONG)vs->locscreen + (r * Coffset);
		    for (c = ulc + 1 ; c < lrc ; c++) {
			t = (UBYTE *) Temp + (c * 2) + 1;
			*t = Attrib;
		    }
		}
	}
			
    }
    if (ulr==lrr && lrr<vs->maxR && lrc<vs->maxC) {
	for (c=ulc;c<=lrc;c++) {
	    t = vs->locscreen + (ulr * vs->maxC * 2) + (c * 2);
	    switch (*t) {
		case 196:
		case 194:
		case 193:
		case 197:
		    *++t = Attrib;
		    break; /* Already a horizontal line here */
		
		case 195:
		case 180:
		case 179:
		    *t++ = 197; /* Horizontal/vertical intersection */
		    *t = Attrib;
		    break;
		    
		case 218:
		    *t++ = 194; /* Horizontal/TL Corner intersection */
		    *t = Attrib;
		    break;
		
		case 191:
		    *t++ = 194; /* Horizontal/TR Corner intersection */
		    *t = Attrib;
		    break;
		    
		case 192:
		    *t++ = 193; /* Horizontal/BL Corner intersection */
		    *t = Attrib;
		    break;
		    
		case 217:
		    *t++ = 193; /* Horizontal/BR Corner intersection */
		    *t = Attrib;
		    break;
		    
		default:
		    *t++ = 196; /* Horizontal line */
		    *t = Attrib;
		    break;
	    }
	}
    }
    if (ulc==lrc && lrr<vs->maxR && lrc<vs->maxC) {
	for (r=ulr;r<=lrr;r++) {
	    t = vs->locscreen + (r * vs->maxC * 2) + (ulc * 2);
	    
	    switch (*t) {
		case 179:
		case 195:
		case 180:
		case 197:
		    *++t = Attrib;
		    break; /* Already a vertical line here */
		
		case 193:
		case 194:
		case 196:
		    *t++ = 197; /* Horizontal/vertical intersection */
		    *t = Attrib;
		    break;
		    
		case 218:
		    *t++ = 195; /* Vertical/TL Corner intersection */
		    *t = Attrib;
		    break;
		
		case 191:
		    *t++ = 180; /* Vertical/TR Corner intersection */
		    *t = Attrib;
		    break;
		    
		case 192:
		    *t++ = 195; /* Vertical/BL Corner intersection */
		    *t = Attrib;
		    break;
		    
		case 217:
		    *t++ = 180; /* Vertical/BR Corner intersection */
		    *t = Attrib;
		    break;
		    
		default:
		    *t++ = 179; /* vertical line */
		    *t = Attrib;
		    break;
	    }
	}
    }
}


static VOID _dotype(vs)
register struct _vsstr *vs;
{
/*
    switch(vs->montype) {
	case 4:
	case 5:
	    printf("\33a4");
	    break;
	    
	case 6:
	    printf("\33a6");
	    break;
    }
*/
}

VOID v_update(vs)
register struct _vsstr *vs;
{
    _dotype(vs);
    MOVE_TO(vs->locscreen,vs->remscreen,vs->monsize);
}

VOID v_bupdate(vs)
register struct _vsstr *vs;
{
    _dotype(vs);
    BMOVE_TO(vs->locscreen,vs->remscreen,vs->monsize);
}

VOID v_retrieve(vs)
register struct _vsstr *vs;
{
    _dotype(vs);
    MOVE_FROM(vs->remscreen,vs->locscreen,vs->monsize);
}

VOID v_bretrieve(vs)
register struct _vsstr *vs;
{
    _dotype(vs);
    BMOVE_FROM(vs->remscreen,vs->locscreen,vs->monsize);
}


VOID v_printf(vs,row,col,args)
register struct _vsstr *vs;
WORD row,col;
UBYTE *args;
{
    register UBYTE *temp,*temp1,*temp2;
    
    temp = myalloc(4096); /* maximum size any printf will be */
    sprintf(temp,args,((ARG_PT) &args)+1);
    temp1 = vs->locscreen + (row * vs->maxC * 2) + (col * 2);
    
    temp2=temp;
    while (*temp2) {
	*temp1++ = *temp2++;
	*temp1++ = vs->attrib;
    }
    free(temp);
}


VOID v_copy(vs1,vs2)
register struct _vsstr *vs1,*vs2;
{
    register UBYTE *t1,*t2;
    register int len;
    
    len = vs1->monsize/4;		/* This must be on TOS */
    
    t2 = vs2->locscreen;		/* This must be in R2 */
    t1 = vs1->locscreen;		/* This must be in R1 */

    COPYD_(t1,t2,len);
    
/*
    while(len--) 
	*t2++ = *t1++;
*/
}

UBYTE *v_locmem(vs)
register struct _vsstr *vs;
{
    return((UBYTE *)vs->locscreen);
}


VOID v_preset(vs,row,col)
register struct _vsstr *vs;
register ULONG row,col;
{
    v_pset(vs,row,col,0);
}


VOID v_pset(vs,row,col,color)
register struct _vsstr *vs;
register ULONG row,col,color;
{
    register struct pix320 *p320;
    register struct pix640 *p640;
    register ULONG Temp;

    if ((row >= vs->maxR) || col >= vs->maxC) 
return;

    switch (vs->montype) {
	case 4:
	case 5:
	    
	    Temp =  ((row & 1) * 8192) 
		    + 80 * (row / 2) + (col / 4);
	    p320 = vs->locscreen + Temp;
	    
	    switch(col&3) {
		case 0:
		    p320->pix0 = color;
		    break;
		
		case 1:
		    p320->pix1 = color;
		    break;
		
		case 2:
		    p320->pix2 = color;
		    break;
		
		case 3:
		    p320->pix3 = color;
		    break;
	    }
	    
	    break;
	    
	case 6:
	    Temp =  ((row & 1) * 8192) 
		    + 80 * (row / 2) + (col / 8);
	    p640 = vs->locscreen + Temp;
	    
	    switch(col&7) {
		case 0:
		    p640->pix0 = color;
		    break;
		
		case 1:
		    p640->pix1 = color;
		    break;
		
		case 2:
		    p640->pix2 = color;
		    break;
		
		case 3:
		    p640->pix3 = color;
		    break;

		case 4:
		    p640->pix4 = color;
		    break;
		
		case 5:
		    p640->pix5 = color;
		    break;
		
		case 6:
		    p640->pix6 = color;
		    break;
		
		case 7:
		    p640->pix7 = color;
		    break;
	    }
	    break;
    }
/*  BMOVE_TO(p320,vs->remscreen+Temp,1); */
}

	    
VOID v_line(vs,Srow,Scol,Drow,Dcol,color)
register struct _vsstr *vs;
register ULONG Srow,Scol,Drow,Dcol,color;
{
    register DOUBLE M,B;
    register ULONG col,row, temp;
    
    M = 1.0;
    
    if (Drow == Srow) {
	for (col=Scol ; col <= Dcol ; col++)
	    v_pset(vs,Drow,col,color);
return;
    }
    if (Dcol == Scol) {
	for (row=Srow ; row <= Drow ; row++)
	    v_pset(vs,row,Dcol,color);
return;
    }
    
    M = ((DOUBLE)(Drow-Srow))/((DOUBLE)(Dcol-Scol));
    B = (DOUBLE)Srow - M * (DOUBLE)Scol;
    
    if ( abs(M) <= 1.0) {
	for (col = Scol; col <= Dcol; col++) {
	    row = (ULONG) (M * (DOUBLE) col + B);
	    v_pset(vs,row,col,color);
	}
	temp = row;
    } else {
	temp = Srow;
	for (col = Scol; col <= Dcol; col++) {
	    row = (ULONG) (M * (DOUBLE) col + B);
	    for (; temp <= row; (M >= 0.0) ? temp++ : temp--) 
		v_pset(vs,temp,col,color);
	}
    }
    if (temp < Drow)
	for (; temp <= Drow; (M >= 0.0) ? temp++ : temp--)
	    v_pset(vs,temp,col,color);
}



VOID v_circle(vs,row,col,radius,color)
register struct _vsstr *vs;
register ULONG row,col,radius,color;
{

    register DOUBLE RAx; 
    register LONG Row, Col, Prox;

    RAx = ((DOUBLE) (vs->maxR) / (DOUBLE) (vs->maxC)) * (23.6/16.8);
#define RA RAx + 0.5
    
    Col = 0;
    Row = radius;

    
    Prox = 3 - 2 * radius;
    
    do {
	v_pset(vs,(ULONG)(row+Row*RA),col+Col,color);
	v_pset(vs,(ULONG)(row-Row*RA),col-Col,color);
	v_pset(vs,(ULONG)(row-Row*RA),col+Col,color);
	v_pset(vs,(ULONG)(row+Row*RA),col-Col,color);
	
	if (Prox < 0)
	    Prox = Prox + 4 * Col + 6;
	else {
	    Prox = Prox + 4 * (Col - Row) + 10;
	    Row--;
	}
	Col++;
	v_pset(vs,(ULONG)(row+Row*RA),col+Col,color);
	v_pset(vs,(ULONG)(row+Row*RA),col-Col,color);
	v_pset(vs,(ULONG)(row-Row*RA),col+Col,color);
	v_pset(vs,(ULONG)(row-Row*RA),col-Col,color);
	v_pset(vs,(ULONG)(row+Col*RA),col+Row,color);
	v_pset(vs,(ULONG)(row+Col*RA),col-Row,color);
	v_pset(vs,(ULONG)(row-Col*RA),col+Row,color);
	v_pset(vs,(ULONG)(row-Col*RA),col-Row,color);

	if (Row == Col) {
	    v_pset(vs,(ULONG)(row+Row*RA),col+Col,color);
	    v_pset(vs,(ULONG)(row-Row*RA),col-Col,color);
	    v_pset(vs,(ULONG)(row-Row*RA),col+Col,color);
	    v_pset(vs,(ULONG)(row+Row*RA),col-Col,color);
	}
    } while ( Col < Row);
}

	

	
	




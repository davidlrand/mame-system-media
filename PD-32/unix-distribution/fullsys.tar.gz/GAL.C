#include <stdio.h>
#include <ctype.h>
	
/* LPT1 =  0x3BC */
/* LPT2 =  0x378 */
/* LPT3 =  0x278 */

#define PSVB 0x40	/* program/verify in PORT A */
#define STRB 0x80	/* /strobe in PORT A */
#define SDIN  1		/* serial_data_in in PORT C */
#define SCLKN 2		/* /serial_clock in PORT C */
#define VCCSW 4		/* VCCP switch in PORT C */
#define VIESW 8		/* VIE switch in PORT C */
#define SDOUT 8		/* /serial data out in PORT B */
#define TENMS 0x10	/* 10msec timeout flag in PORT B */
#define FIFTYMS 0x20	/* 50msec timeout flag in PORT B */

struct palinft {
	char		type[9];
	unsigned long	arch[3];
	int		rows;
};

struct palinft palinfo[42];

unsigned char  rowdata[64][82];
unsigned char prowdata[64][82];
unsigned char  arcdata[82];
int portbase;
int fuserows;
char paltyp[128];

main()
{
	char temp[128], fname[128], key, dummy, buff[128], *fgets(), *q;
	int  fuse, prodterm, row, i, j, c, t, errors;
	unsigned char tbyte;
	FILE *fi, *fopen();

	fi = fopen("GAL.CFG","r");
	if (fi == NULL) {
		printf("GAL: Configuration file GAL.CFG doesn't exist.\n");
		exit(1);
	}
	while (fgets(temp,128,fi) != NULLPTR)
		if (temp[0] != '#')	/* eat comment lines */
			break;

	sscanf(temp, "%x", &portbase);	/* this line should have portbase */

	while (fgets(temp,128,fi) != NULLPTR)
		if (temp[0] != '#')	/* eat comment lines */
			break;

	j = 0;
	do {
		sscanf(temp, "%s %lx %lx %lx %d",
		&palinfo[j].type, &palinfo[j].arch[0], &palinfo[j].arch[1],
		&palinfo[j].arch[2],&palinfo[j].rows);
		j++;
	} while (fgets(temp,128,fi) != NULLPTR);
	fclose(fi);

	if (portbase == 0x378) {
		printf("You may now mount a GAL device into the programmer.");
		printf(" Using LPT2\n");
	} else if (portbase == 0x278) {
		printf("You may now mount a GAL device into the programmer.");
		printf(" Using LPT3\n");
	} else if (portbase == 0x3bc) {
		printf("You may now mount a GAL device into the programmer.");
		printf(" Using LPT1\n");
	} else {
		printf("Couldn't find valid printer port in GAL.CFG file\n");
		exit(1);
	}
	row = 0;
	outportb(portbase + 2, SCLKN );		/* turn power off */
	outportb(portbase, row | STRB);

restart:	    
	for (row = 0; row <= 63; row++)
		for (i = 0; i < 82; i++) {
			prowdata[row][i] = 0;
			rowdata[row][i] = 0;
	}
	printf("Enter JEDEC file name:? ");
	gets(fname);
	fi = fopen(fname,"r");
	if (fi == NULL) {
		printf("File doesn't exist. Enter the type of PAL you\n");
		printf("wish to emulate (eg PAL16L8) : ");
		gets(temp);
		if (strlen(temp) == 0)
			exit(1);
		q = temp;
		while (*q) {
			*q++ = toupper(*q);
		}
	}
	else {
		fgets(temp,128,fi);	/* get rid of 1st line */
		fgets(temp,128,fi);	/* the 2nd line has the pal type */
	}

	sscanf(temp,"%s",paltyp);

	if (findpal() == 0) {
		printf("Don't recognise Pal %s\n",paltyp);
		fclose(fi);
		exit(1);
	}
	if (fi)
		printf("PAL type = %s\n",paltyp);

	while (1) {
		for (row = 0; row <= 63; row++)
			for (i = 0; i < 82; i++) 
				rowdata[row][i] = 0;
		printf("\nCopy, Erase, File, List, Program, Quit, Secure, Bulk erase:? ");
		gets(temp);		/* Read line */
		printf("\n");
		c = toupper(temp[0]);	/* Get first char, and convert */

		switch(c) {

		    case 'C':
			printf("Insert the original, ENTER when ready: ");
			gets(temp);		/* wait for response */
			outportb(portbase + 2, SCLKN | VCCSW);
			outportb(portbase + 2, SCLKN | VCCSW | VIESW);
			readbuf(prowdata);

			for (row = 0; row < fuserows; row++)
			    for (j = 0 ; j < 64 ; j++) 
				prowdata[row][j] = ~(prowdata[row][j] >> 3);
			for (j = 0 ; j < 82 ; j++)
				prowdata[60][j] = ~(prowdata[60][j] >> 3);

			printf("Insert the target GAL, ENTER when ready: ");
			gets(temp);
			proggal();
			break;

		    case 'F':
			if (fi)
				fclose(fi);
			goto restart;

		    case 'Q':
			fclose(fi);
			exit(0);

		    case 'S':
			row = 61;
			outportb(portbase + 2, SCLKN | VCCSW);
			outportb(portbase + 2, SCLKN | VCCSW | VIESW | SDIN);
			outportb(portbase, row | STRB);
			outportb(portbase, row | STRB | PSVB);
			outportb(portbase, row | PSVB);
			while((inportb(portbase + 1) & FIFTYMS))
				;
			outportb(portbase, row | STRB | PSVB);
			outportb(portbase, row | STRB);
			outportb(portbase + 2, 0);
			printf("GAL device now secured.\n");
			break;

		    case 'E':
			if (erasegal(0) == 0)
				printf("GAL erased.\n");
			else printf("Error during GAL erasure.\n");
			break;

		    case 'B':
			if (erasegal(1) == 0)
				printf("GAL erased.\n");
			else printf("Error during GAL erasure.\n");
			break;
		    
		    case 'P':
			if (!fi)
				goto restart;

			fseek(fi, 0L, 0);	/* BOF the file */

			for ( j = 0; j < 7; j++)
				fgets(temp, 128, fi);

			while (1) {
			  fscanf(fi,"%c%4d%c%s", &key, &fuse, &dummy, &buff);
			  fgets(temp, 128, fi);
			  if (key != 'L')
				break;
			  prodterm = fuse / fuserows;
			  for ( j = 0; j < fuserows; j++) {
				if (buff[j] == '*')
					break;
				if (buff[j] == '1')
					prowdata[j][prodterm] = 1;
			  }
			}
			for (i = 0; i < 82; i++)
				prowdata[60][i] = arcdata[i];
			proggal();
			break;
		    
		    case 'L':
			outportb(portbase + 2, SCLKN | VCCSW);
			outportb(portbase + 2, SCLKN | VCCSW | VIESW);
			readbuf(rowdata);
			displaybuf(rowdata);
			break;

		    default:
			printf("Command error.\n");
		}
			
	}
}

proggal()
{
	int i, j, t, row, errors;
	unsigned char temp[8];

	if (erasegal(0) != 0) {	/* erase before programming */
		printf("Error during GAL erasure.\n");
		return;		/* terminate */
	}
	for (i = 0; i < 8; i++) {
		t = 0;
		for (j = 0; j < 8; j++)
			t |= (((rowdata[fuserows][i * 8 + j] & 8) >> 3) << j);
		temp[i] = ~t;
	}
	t = temp[6] | (temp[7] << 8);
	printf("Erase/program cycle #%d\n", t);

	outportb(portbase + 2, SCLKN | VCCSW);
	outportb(portbase + 2, SCLKN | VCCSW | VIESW);
	for (row = 0; row < fuserows; row++)
		blowrow(prowdata, row, 64);
	blowrow(prowdata, 60, 82);

	/* GAL programmed, now verify against the fuse buffer */

	readbuf(prowdata);
	errors = 0;
	for (row = 0; row < fuserows; row++)
		for (j = 0 ; j < 64 ; j++) 
			if ((prowdata[row][j] != 8) && 
				(prowdata[row][j] != 1))
					errors++;
	for (j = 0 ; j < 82 ; j++)
		if ((prowdata[60][j] != 8) &&
			(prowdata[60][j] != 1))
				errors++;
	if (errors == 0)
		printf("Programming verified.\n");
	else printf("Program verify error.\007\n");
}

erasegal(bulk)
int bulk;
{
	int i, j, row, t, tbyte;
	unsigned char temp[8];

	outportb(portbase + 2, SCLKN | VCCSW);
	outportb(portbase + 2, SCLKN | VCCSW | VIESW);
	if (!bulk) {	/* if not bulk erase retain signature */
		readbuf(rowdata);	/* get the electronic signature */
		for (i = 0; i < 8; i++) {
		   t = 0;
		   for (j = 0; j < 8; j++)
			t |= (((rowdata[fuserows][i * 8 + j] & 8) >> 3) << j);
		   temp[i] = ~t;
		}
	}
	row = 63;
	outportb(portbase + 2, SCLKN | VCCSW);
	outportb(portbase + 2, SCLKN | VCCSW | VIESW | SDIN);
	outportb(portbase, row | STRB);
	outportb(portbase, row | STRB | PSVB);
	outportb(portbase, row | PSVB);
	while((inportb(portbase + 1) & FIFTYMS))
		;
	outportb(portbase, row | STRB | PSVB);
	outportb(portbase, row | STRB);
	readbuf(rowdata);
	tbyte = 0;
	for (row = 0; row < fuserows; row++)
		for (j = 0; j < 64; j++)
			tbyte |= rowdata[row][j];
	for (j = 0; j < 82; j++)
		tbyte |= rowdata[60][j];

	if (temp[6] == 0xff && temp[7] == 0xff) {	/* no signature */
		temp[6] = 0;
		temp[7] = 0;
	}
	else {
		t = temp[6] | (temp[7] << 8);
		t++;
		temp[6] = t & 0xff;
		temp[7] = t >> 8;
	}
	for (i = 0; i < 8; i++) {
		t = temp[i];
		for (j = 0; j < 8; j++) {
			rowdata[fuserows][i * 8 + j] = (t & 1);
			t >>= 1;
		}
	}
	outportb(portbase + 2, SCLKN | VCCSW);
	outportb(portbase + 2, SCLKN | VCCSW | VIESW);
	if (!bulk)	/* retain signature if not bulk erase */
		blowrow(rowdata, fuserows, 64);		/* signature */
	readbuf(rowdata);
	return(tbyte);
}

findpal()
{
	int j, k, l;
	unsigned long i;

	for(j = 0; j < (sizeof(palinfo)/sizeof(struct palinft)); j++) {
		if (strcmp(paltyp, &palinfo[j].type) == 0)
			break;
	}
	if (j == (sizeof(palinfo)/sizeof(struct palinft)))
		return(0);
	fuserows = palinfo[j].rows;

	i = palinfo[j].arch[0];	/* get low 32 product term disables */
	for (k = 0; k < 32; k++) {
		l = i & 1;
		i >>= 1;
		arcdata[k] = l;
	}

	i = palinfo[j].arch[1];	/* get high 32 product term disables */
	for (k = 50; k < 82; k++) {
		l = i & 1;
		i >>= 1;
		arcdata[k] = l;
	}

	i = palinfo[j].arch[2];
	if (i == 0L) {
		printf("PAL %s not supported\n", &palinfo[j].type);
		exit(1);
	}
	for (k = 32; k < 50; k++) {
		l = i & 1;
		i >>= 1;
		arcdata[k] = l;
	}

	return(fuserows);
}

blowrow(buffer,row,size)
unsigned char buffer[64][82];
int row, size;
{
	outportb(portbase, row | STRB);
	loadsr(&buffer[row][0], size, portbase + 1);
	outportb(portbase, row | STRB | PSVB);
	outportb(portbase, row | PSVB);
	while ((inportb(portbase + 1) & TENMS))
		;
	outportb(portbase, row | STRB | PSVB);
	outportb(portbase, row | STRB);
	outportb(portbase, row);
	outportb(portbase, row | STRB);
	loadsr(&buffer[row][0], size, portbase + 1);
}

readbuf(buffer)
unsigned char buffer[64][82];
{
	int row;

	for (row = 0; row <= fuserows; row++) {
		outportb(portbase, row | STRB);
		outportb(portbase, row);
		outportb(portbase, row | STRB);
		loadsr(&buffer[row][0], 64, portbase + 1);
	}
	outportb(portbase, 60 | STRB);
	outportb(portbase, 60 );
	outportb(portbase, 60 | STRB);
	loadsr(&buffer[60][0], 82, portbase + 1);
	outportb(portbase + 2, SCLKN | VCCSW);
	outportb(portbase + 2, SCLKN);
}

displaybuf(buffer)
unsigned char buffer[64][82];
{
	int  row, j;

	for (row = 0 ; row <= fuserows ; row++ ) {
		printf("row = %02d\n", row);
		for ( j = 63 ; j >= 0 ; j--) {
			printf("%d",(buffer[row][j] & 8) ? 0 : 1);
			if (j && !(j % 4))
				printf(" ");
		}
		printf("\n");
	}
	printf("\nArchitecture word\n");
	for ( j = 81 ; j >= 41 ; j--)
		printf("%d",(buffer[60][j] & 8) ? 0:1);
	printf("\n");
	for ( j = 40 ; j >=0 ; j--)
		 printf("%d",(buffer[60][j] & 8) ? 0:1);
	printf("\n\n");
}


loadsr(ptr, siz, port)
char *ptr;
int siz;
int port;
{
#asm
	push	si
	mov	dx,8[bp]
	mov	cx,6[bp]
	mov	si,4[bp]
	cli
loop1:	in	al,dx
	and	al,8
	mov	ah,[si]
	and	ah,1
	or	al,ah
	mov	[si],al
	or	al,0eh
	inc	dx
	out	dx,al
	nop
	nop
	and	al,0dh
	out	dx,al
	nop
	nop
	or	al,0eh
	out	dx,al
	dec	dx
	inc	si
	loop	loop1
	sti
	pop	si
#endasm
}

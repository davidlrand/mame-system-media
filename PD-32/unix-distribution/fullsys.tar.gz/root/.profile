TZ=EST5EDT
PATH=/bin:/usr/bin:/etc:/lbin:.
TERM=ibmpc
TERMINFO=/llib/terminfo
export TZ PATH TERM TERMINFO
umask 02
stty erase '^h' echoe
